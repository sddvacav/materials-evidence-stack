import json,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_manifest(self): self.assertGreaterEqual(len(json.loads((R/'MANIFEST.json').read_text())['members']),40)
if __name__=='__main__': unittest.main()
