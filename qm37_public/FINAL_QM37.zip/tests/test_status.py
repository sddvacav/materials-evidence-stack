import json,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_status(self): self.assertEqual(json.loads((R/'WINDOW_STATUS.json').read_text())['status'],'CONTINUE_DATA_GAP')
if __name__=='__main__': unittest.main()
