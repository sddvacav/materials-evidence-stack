import json,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_ceiling(self): self.assertLessEqual(json.loads((R/'WINDOW_STATUS.json').read_text())['claim_level_max'],2)
if __name__=='__main__': unittest.main()
