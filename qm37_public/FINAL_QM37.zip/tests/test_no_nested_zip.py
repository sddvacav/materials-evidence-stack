import unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_no_zip(self): self.assertEqual(list(R.rglob('*.zip')),[])
if __name__=='__main__': unittest.main()
