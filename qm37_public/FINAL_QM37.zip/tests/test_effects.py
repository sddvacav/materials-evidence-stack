import csv,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_effects(self): self.assertEqual(len(list(csv.DictReader(open(R/'EFFECT_ESTIMATES.csv',encoding='utf-8-sig')))),36)
 def test_decay(self):
  d=list(csv.DictReader(open(R/'MECHANISM_DECAY_RATES.csv',encoding='utf-8-sig'))); m=[x for x in d if x['sample_uid']=='dose_balanced_mean'][0]; self.assertLess(float(m['retained_fraction_800_vs_600']),0.17)
if __name__=='__main__': unittest.main()
