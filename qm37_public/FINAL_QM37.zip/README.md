# FINAL_QM37

Reproducible high-temperature mechanism-transition web return.

- Snapshot: `RECOVERY_QM37_21804e6cf3d72333`
- Status: `CONTINUE_DATA_GAP`
- Claim ceiling: level 2
- Cohort rows: 70
- Matched pairs/effects: 36/36
- Figure files: 12
