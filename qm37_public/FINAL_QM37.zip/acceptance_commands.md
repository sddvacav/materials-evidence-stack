# Acceptance commands

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m unittest discover -s tests -v
python analysis_code/verify_package.py --root .
```
