"""Rebuild contract for QM37. The delivered CSV/JSON and plot scripts are authoritative replay inputs."""
from pathlib import Path
if __name__ == '__main__':
    print('QM37 rebuild contract loaded; execute plot_code scripts after installing requirements.')
    print('root=', Path(__file__).resolve().parents[1])
