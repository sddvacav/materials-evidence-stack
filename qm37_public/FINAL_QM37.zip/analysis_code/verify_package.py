import argparse, hashlib, json
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1048576),b''): h.update(c)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default='.'); args=ap.parse_args(); root=Path(args.root)
    checks={}
    for line in (root/'CHECKSUMS.sha256').read_text().splitlines():
        h,p=line.split('  ',1); checks[p]=h
    for p,h in checks.items(): assert sha(root/p)==h,(p,'hash mismatch')
    st=json.loads((root/'WINDOW_STATUS.json').read_text()); assert st['claim_level_max']<=2 and st['status']=='CONTINUE_DATA_GAP'
    assert not list(root.rglob('*.zip'))
    for stem in ['FIG01_mechanism_state_map','FIG02_contribution_decay','FIG03_changepoint_intervals','FIG04_service_risk_network']:
        for ext in ['svg','pdf','png']: assert (root/'figures'/f'{stem}.{ext}').exists()
    print('PASS',len(checks),'checksums')
if __name__=='__main__': main()
