import csv, matplotlib.pyplot as plt
rows=list(csv.DictReader(open('../figure_data/mechanism_state_map.csv',encoding='utf-8-sig')))
tracks=sorted(set(r['track'] for r in rows)); ym={x:i for i,x in enumerate(tracks)}
fig,ax=plt.subplots(figsize=(9,5))
for r in rows: ax.scatter(float(r['temperature_c']),ym[r['track']]); ax.annotate(r['state'],(float(r['temperature_c']),ym[r['track']]),fontsize=6)
ax.set_yticks(range(len(tracks)),tracks); ax.set_xlabel('Temperature (°C)'); ax.set_title('Mechanism-state support (not calibrated probability)'); fig.savefig('replot.svg',bbox_inches='tight')
