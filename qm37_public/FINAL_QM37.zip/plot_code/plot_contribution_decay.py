import csv, matplotlib.pyplot as plt
rows=list(csv.DictReader(open('../figure_data/contribution_decay.csv',encoding='utf-8-sig'))); series=sorted(set(r['series'] for r in rows))
fig,ax=plt.subplots()
for s in series:
 q=sorted([r for r in rows if r['series']==s],key=lambda r:float(r['temperature_c'])); ax.plot([float(r['temperature_c']) for r in q],[float(r['delta_uts_mpa']) for r in q],marker='o',label=s)
ax.legend(); ax.set_xlabel('Temperature (°C)'); ax.set_ylabel('ΔUTS (MPa)'); fig.savefig('replot.svg',bbox_inches='tight')
