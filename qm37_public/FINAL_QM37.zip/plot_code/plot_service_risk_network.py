import csv, matplotlib.pyplot as plt
rows=list(csv.DictReader(open('../figure_data/service_risk_network.csv',encoding='utf-8-sig'))); nodes=sorted(set([r['source'] for r in rows]+[r['target'] for r in rows]))
fig,ax=plt.subplots(figsize=(9,7)); ax.axis('off')
for i,n in enumerate(nodes): x=(i%4)/3; y=1-(i//4)/4; ax.scatter(x,y,s=700); ax.text(x,y,n,ha='center',va='center',fontsize=6)
fig.savefig('replot.svg',bbox_inches='tight')
