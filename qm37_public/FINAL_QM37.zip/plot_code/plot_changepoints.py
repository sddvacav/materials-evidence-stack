import csv, matplotlib.pyplot as plt
rows=[r for r in csv.DictReader(open('../figure_data/changepoints.csv',encoding='utf-8-sig')) if r['axis']=='temperature_c' and r['lower_bound'] and r['upper_bound']]
fig,ax=plt.subplots()
for i,r in enumerate(rows): ax.hlines(i,float(r['lower_bound']),float(r['upper_bound']),lw=4)
ax.set_yticks(range(len(rows)),[r['paper_uid'] for r in rows]); ax.set_xlabel('Temperature (°C)'); fig.savefig('replot.svg',bbox_inches='tight')
