# Methods

Atomic unit: paper × sample × actual composition × precursor × reinforcement × process × heat treatment × microstructure × test mode × temperature × strain rate × orientation × property. Same-source pairs use delta, log response ratio, percent change and unit-content efficiency. Internal TiBw/Ti65 effects are matched by powder-size family, route and temperature. MAO effects estimate welded-joint architecture preservation rather than pure reinforcement. KIM effects estimate dose-associated apparent oxidation activation-energy changes.

Confidence and prediction intervals are left blank where raw replicate dispersion is absent. Mechanism probabilities are declared NOT_IDENTIFIABLE; reported state labels and normalized support indices remain distinct. Change points are direct brackets, processing-map domains, censoring bounds or explicit gaps. Cross-mode pooling of tension, compression, creep and oxidation is prohibited.
