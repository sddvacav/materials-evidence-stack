# Limitations

1. Authoritative V29 atomic records, provenance and canonical condition UIDs were unavailable.
2. The 600–800°C strengthening-decay series is one internal family without specimen-level dispersion or independent replication.
3. Hot-compression DRV/DRX evidence is a processing domain, not an 800°C service test.
4. Oxidation evidence is environment- and time-specific.
5. Direct 800°C long-duration creep and co-measured oxidation–mechanics evidence are absent.
6. Mechanism dominance probabilities, random-effects heterogeneity and prediction intervals are not identifiable.
