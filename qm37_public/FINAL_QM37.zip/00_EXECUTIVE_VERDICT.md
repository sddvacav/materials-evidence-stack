# QM37 Executive Verdict

Snapshot: `RECOVERY_QM37_21804e6cf3d72333`  
Status: `CONTINUE_DATA_GAP`  
Maximum claim level: **2 — same-work/same-paper association**.

## Quantitative result
The same-work TiBw/Ti65 short-term tensile comparison contains 9 grade-A pairs. The dose-balanced mean UTS increment is 123.7 MPa at 600°C, 52.7 MPa at 700°C, and 20.3 MPa at 800°C. Only 16.4% of the 600°C increment remains at 800°C, an 83.6% attenuation. This is not a calibrated service-retention probability and has no specimen-level CI.

## Mechanism transition
Mao 2013 brackets a source-specific fracture transition between 600 and 650°C from TiBw fracture plus ductile voiding to interface decohesion plus void coalescence. Hot-compression papers show DRV/DRX and processing-instability domains, but those cannot substitute for 800°C service exposure.

## 800°C controlling risk
For 100 h cyclic oxidation in air, Wei 2017 reports protective/nearly parabolic behavior at 600°C, partially damaged/quasi-linear behavior at 700°C, and complete scale spallation/linear kinetics at 800°C. Oxidation-scale damage/spallation is therefore the strongest directly evidenced 800°C long-time risk in air. Creep damage may co-control, but no direct 800°C long-duration creep dataset is present.

## Claim ceiling
No Gold promotion, production-model registration, validated formulation, causal claim, or 800°C service qualification is authorized.
