import math
def mass_rom(f,r):
 s=sum(f.values());return 1/sum((v/s)/r[k] for k,v in f.items())
def volume_rom(f,r):
 s=sum(f.values());return sum((v/s)*r[k] for k,v in f.items())
def specific(y,rho):
 if rho<=0:raise ValueError("density")
 return y/rho
def pct(t,c):
 if c==0:raise ValueError("control")
 return 100*(t/c-1)
def dominates(rt,yt,rc,yc):return rt<=rc and yt>=yc and (rt<rc or yt>yc)
def robust_density(rt,sdt,rc,sdc,z=1.96):return (rc-rt)>z*math.sqrt(sdt*sdt+sdc*sdc)
def utility(c,t,w):
 vals=[]
 for k,wt in w.items():
  if k in c and k in t:vals.append((wt,(-1 if k=="density" else 1)*math.log(t[k]/c[k])))
 if not vals:raise ValueError("dimensions")
 return sum(a*b for a,b in vals)/sum(a for a,_ in vals)
