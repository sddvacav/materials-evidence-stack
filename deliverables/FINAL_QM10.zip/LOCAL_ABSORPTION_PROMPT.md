# LOCAL ABSORPTION PROMPT — QM10

Verify checksums, ZIP CRC and independent extraction. Bind `QM10_DERIVED_b672f3926f0a30f4` to authoritative Q40 IDs/hashes; re-open all seven originals and replace reference placeholders with original byte hashes plus exact locations. Re-run the density/porosity firewall. Acquire matched W/Ta-free controls with measured density. Keep heavy-element effects `NOT_IDENTIFIABLE` until overlap exists. Recompute plots/tests and return a signed absorption receipt. Never self-promote Gold, production models or VALIDATED formulations.
