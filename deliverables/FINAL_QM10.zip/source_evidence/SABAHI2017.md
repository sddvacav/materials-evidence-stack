DOI 10.1080/00325899.2016.1265805; source filecite:turn20file1; Archimedes density, n=4 tensile and bending data used.
