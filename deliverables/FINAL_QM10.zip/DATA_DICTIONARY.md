# Data dictionary

`density_measured_g_cm3` is Archimedes bulk density; `density_theoretical_g_cm3` is paper ROM/database/calculated full density. `specific_*` divides the property by density in g cm-3. Match grade A/B/C/E denotes strict paired/calculated limitation/database-cross-source/descriptive. `propagation_*` is measurement propagation, not a meta-analytic CI. `robust_dominance_vs_control` requires a 1.96-sigma density margin.
