# QM10 Executive Verdict — Density, Specific Strength, Specific Modulus, and Real Multi-objective Gain

`WINDOW=QM10 | SNAPSHOT=QM10_DERIVED_b672f3926f0a30f4 | INPUT_MODE=QUANT_EXECUTE/COHORT_BUILD`

## Decision

The mass-normalized benefit is conditional, not universal. Ceramic reinforcement improves specific performance only when strength/stiffness gains exceed density, porosity, agglomeration and ductility costs.

- Strongest measured-density positive anchor: SPS Ti–2.4 wt% TiB2 / intended 4 vol% TiB changes specific UTS by **8.93%** on Archimedes bulk density and **9.97%** on full-density ROM. The sign survives removal of porosity credit.
- Dose is non-monotonic: Yan 10 vol% TiB gives **5.30%** full-density specific UTS, while 15 and 20 vol% give **-31.89%** and **-52.05%**; high-dose agglomeration/porous regions are reported.
- Calculated-density sensitivities are promising but lower-grade: PLDED 12.88 vol% TiC gives **82.09%** calculated specific UTS. Hybrid TiB+TiC/Ti6242 gives **34.52%** specific UTS and **18.21%** specific E, but EL falls from 10% comparator to 1.35%; ductility-aware utility is negative.
- Specific modulus: the 0–5 vol% TiB/Ti-6Al-4V series changes calculated specific E from **25.35** to **27.61 GPa/(g cm-3)**, or **8.92%**.
- W/Ta: Ti65 nominal 2.8 wt% W+Ta adds **0.09284 g cm-3** or **2.09%** density versus equal-mass Ti substitution in ROM. Strength benefit is **NOT_IDENTIFIABLE** because no matched W/Ta-free control with measured density exists. The required response surface is therefore a support map with no fit.

## Porosity firewall

Measured bulk density is reported, but intrinsic material efficiency is judged primarily on full-density/calculated density. Lower bulk density caused by pores is never credited as lightweighting.

## Pareto and utility

Yan 10 vol% TiB nominally dominates its matrix in UTS and paper-ROM density, but the density margin is below declared uncertainty and is not robust. The Sabahi composite is the strongest measured-density tensile case. Qin hybrid is not a complete multi-objective win once elongation is included.

## Claim ceiling

Maximum claim level: **2 — same-paper paired association**. No universal coefficient, heavy-element response surface, Gold promotion, production-model registration or VALIDATED formulation is supported.

## Evidence accounting

- Project packages registered: 26.
- Direct original papers used: 7.
- Independent paper families: 7.
- Atomic sample-condition rows: 22.
- Physical matched comparisons: 12.
- Property × density-basis effect rows: 33.
- Open conflicts: 6.
- Quantitative figures: 6, each with CSV + Python + SVG/PDF/600-dpi PNG.

`STATUS: CONTINUE_DATA_GAP | WINDOW=QM10 | MISSING=AUTHORITATIVE_Q40_INPUT_SNAPSHOT+MATCHED_W_TA_FREE_CONTROL_WITH_MEASURED_DENSITY+HEAVY_ELEMENT_RESPONSE_SURFACE_SUPPORT | NEXT=LOCAL_BIND_SNAPSHOT_AND_REQUEST_MATCHED_DENSITY_RECORDS`
