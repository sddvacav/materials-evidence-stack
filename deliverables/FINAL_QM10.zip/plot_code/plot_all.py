from __future__ import annotations
import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"figure_data"; FIG=ROOT/"figures"
def read(n):
    with (DATA/n).open(encoding="utf-8",newline="") as f:return list(csv.DictReader(f))
def num(x):
    try:return float(x)
    except:return None
def save(fig,stem):
    for ext in ["png","pdf","svg"]:fig.savefig(FIG/f"{stem}.{ext}",dpi=600 if ext=="png" else None,bbox_inches="tight")
    plt.close(fig)
def f1():
    d=read("F1_uts_density.csv"); fig,ax=plt.subplots(figsize=(7.2,5.4))
    for r in d:
        m="s" if num(r["heavy_wt_pct"])>0 else ("o" if num(r["dose_vol_pct"])>0 else "^")
        ax.scatter(num(r["density_g_cm3"]),num(r["UTS_MPa"]),marker=m); ax.annotate(r["sample_uid"],(num(r["density_g_cm3"]),num(r["UTS_MPa"])),fontsize=6,xytext=(3,3),textcoords="offset points")
    ax.set(xlabel="Fully dense / calculated density (g cm$^{-3}$)",ylabel="Ultimate tensile strength (MPa)",title="UTS–density map: absolute and mass-normalized benefit")
    ax.text(.01,.01,"7 independent papers; cross-family positions are descriptive",transform=ax.transAxes,fontsize=8); save(fig,"QM10_F1_UTS_density_Pareto")
def f2():
    d=sorted(read("F2_specific_uts_forest.csv"),key=lambda r:num(r["specific_UTS_change_pct"])); fig,ax=plt.subplots(figsize=(8.5,max(5.5,.38*len(d)+1.8)))
    for i,r in enumerate(d):
        x=num(r["specific_UTS_change_pct"]); lo=num(r["lower_pct"]); hi=num(r["upper_pct"]); m="o" if r["density_basis"]=="measured_bulk" else "s"
        if lo is not None and hi is not None:ax.errorbar(x,i,xerr=[[x-lo],[hi-x]],fmt=m,capsize=3)
        else:ax.plot(x,i,marker=m,linestyle="None")
    ax.axvline(0,linewidth=1); ax.set_yticks(range(len(d))); ax.set_yticklabels([r["label"] for r in d],fontsize=7); ax.set(xlabel="Change in specific UTS (%)",title="Paired specific-strength effects")
    ax.text(.01,.01,"Bands are measurement propagation, not meta-analytic CI",transform=ax.transAxes,fontsize=8); save(fig,"QM10_F2_specific_strength_forest")
def f3():
    d=read("F3_density_calibration.csv"); x=[num(r["theoretical_density_g_cm3"]) for r in d]; y=[num(r["measured_density_g_cm3"]) for r in d]; fig,ax=plt.subplots(figsize=(6.4,5.4)); ax.scatter(x,y); lo=min(x+y)-.02; hi=max(x+y)+.02; ax.plot([lo,hi],[lo,hi],linestyle="--")
    for r in d:ax.annotate(r["sample_uid"],(num(r["theoretical_density_g_cm3"]),num(r["measured_density_g_cm3"])),fontsize=7,xytext=(3,3),textcoords="offset points")
    ax.set(xlim=(lo,hi),ylim=(lo,hi),xlabel="Theoretical / ROM density (g cm$^{-3}$)",ylabel="Archimedes bulk density (g cm$^{-3}$)",title="Density-source calibration: gap = porosity")
    ax.text(.02,.02,"7 samples from 2 independent papers",transform=ax.transAxes,fontsize=8); save(fig,"QM10_F3_density_source_calibration")
def f4():
    d=read("F4_heavy_support.csv"); fig,ax=plt.subplots(figsize=(7.2,5.4))
    for r in d:
        m="s" if r["support_class"]=="heavy_family" else "o"; ax.scatter(num(r["heavy_wt_pct"]),num(r["specific_UTS"]),s=25+5*num(r["dose_vol_pct"]),marker=m)
        if m=="s":ax.annotate(r["sample_uid"],(num(r["heavy_wt_pct"]),num(r["specific_UTS"])),fontsize=7,xytext=(3,3),textcoords="offset points")
    ax.set(xlabel="W + Ta content (wt.%)",ylabel="Specific UTS (MPa / (g cm$^{-3}$))",title="Heavy-element support map — response surface NOT IDENTIFIABLE")
    ax.text(.02,.02,"Only one W/Ta-bearing family; fitting prohibited",transform=ax.transAxes,fontsize=8); save(fig,"QM10_F4_heavy_element_support_not_response_surface")
def f5():
    d=sorted(read("F5_temperature.csv"),key=lambda r:num(r["temperature_C"])); fig,ax=plt.subplots(figsize=(6.8,5.2)); x=[num(r["temperature_C"]) for r in d]; y=[num(r["specific_UTS"]) for r in d]; ax.plot(x,y,marker="o")
    for r in d:ax.annotate(f"{100*num(r['retention_vs_RT']):.1f}%",(num(r["temperature_C"]),num(r["specific_UTS"])),fontsize=8,xytext=(3,3),textcoords="offset points")
    ax.set(xlabel="Test temperature (°C)",ylabel="Specific UTS using RT density",title="Hybrid TiB+TiC/Ti6242 temperature retention")
    ax.text(.02,.02,"Single composite series; no same-temperature matrix control",transform=ax.transAxes,fontsize=8); save(fig,"QM10_F5_temperature_specific_strength_retention")
def f6():
    d=sorted(read("F6_specific_E.csv"),key=lambda r:num(r["dose_vol_pct"])); fig,ax=plt.subplots(figsize=(6.8,5.2)); ax.plot([num(r["dose_vol_pct"]) for r in d],[num(r["specific_E"]) for r in d],marker="o"); ax.set(xlabel="TiB fraction (vol.%)",ylabel="Specific elastic modulus",title="TiB dose–specific modulus association"); ax.text(.02,.02,"One cross-source series; descriptive support only",transform=ax.transAxes,fontsize=8); save(fig,"QM10_F6_TiB_dose_specific_modulus")
def main():FIG.mkdir(exist_ok=True); f1();f2();f3();f4();f5();f6()
if __name__=="__main__":main()
