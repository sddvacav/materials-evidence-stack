# FINAL_QM10

Snapshot `QM10_DERIVED_b672f3926f0a30f4`. Start with `00_EXECUTIVE_VERDICT.md`. Run `python plot_code/plot_all.py` and `python -m unittest discover -s tests -v`. Status is `CONTINUE_DATA_GAP`, not authoritative absorption.
