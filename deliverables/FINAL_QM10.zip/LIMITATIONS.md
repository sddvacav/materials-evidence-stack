# LIMITATIONS — QM10

1. V29 `ATOMIC_RECORDS`, authoritative `PROVENANCE.jsonl`, conflict/exclusion registries and Q40 snapshot were not mounted; `QM10_DERIVED_b672f3926f0a30f4` is derived and non-authoritative.
2. Only two independent papers provide measured bulk density plus tensile controls; pooled hierarchical inference is not defensible.
3. Several Yan relative-density values are figure-derived; exact n/shared-control covariance is unresolved.
4. Wang, Qin, Zhao, Ti65 and the grinding row use calculated/database density; porosity and thermal expansion are incompletely observed.
5. Qin comparator is not same-batch and TiB/TiC density split is a sensitivity assumption.
6. Only one W/Ta-bearing family exists; heavy-element coefficient, response surface and heavy-element × reinforcement interaction are NOT_IDENTIFIABLE.
7. Cross-family Pareto positions are descriptive.
8. No Gold promotion, production-model registration or validated recipe is made.
