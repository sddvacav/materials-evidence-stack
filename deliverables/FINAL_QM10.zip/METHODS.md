# METHODS — QM10

Derived snapshot `QM10_DERIVED_b672f3926f0a30f4` is a deterministic, non-authoritative reconstruction from directly opened original papers plus project registries. It does not replace the missing V29/Q40 authoritative atomic snapshot.

For property Y, paired outputs are ΔY, lnRR and percent change. Specific properties use Y/rho. Measured bulk and fully-dense/calculated density are separated. Full-density/calculated density is the primary intrinsic material-efficiency basis because porosity cannot be counted as a mass benefit.

Density provenance is measured Archimedes, paper ROM, mass-fraction ROM, volume-fraction ROM or database prior. Declared density uncertainty is propagated analytically. Missing composition/phase-fraction uncertainty is not invented.

Grade A is same-paper strict; B carries calculated-density limitations; C uses database/cross-source comparators; E is descriptive. Maximum claim level is 2. Measurement-propagation bands are not meta-analytic CIs. Random-effects pooling remains NOT_IDENTIFIABLE when compatible variances or independent-paper support are insufficient.

UTS-density dominance is evaluated only within paper/family. Robust density dominance requires a 1.96-sigma margin. Utility uses declared log-ratio weights and renormalizes over observed dimensions. LOPO is direction-only because k=2 direct measured-density anchors cannot estimate heterogeneity.

Seed: 20260713. No production model was trained or registered.
