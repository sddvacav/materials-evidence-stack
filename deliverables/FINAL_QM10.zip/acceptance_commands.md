# Acceptance commands

```bash
python -m unittest discover -s tests -v
python plot_code/plot_all.py
sha256sum -c CHECKSUMS.sha256
unzip -t ../deliverables/FINAL_QM10.zip
```
