# QM01 Executive Verdict

`WINDOW=QM01 | SNAPSHOT=QM01_RECOVERY_XW01_V11_20260713 | INPUT_MODE=COHORT_BUILD`

## Terminal scientific verdict

The available project sources support a **Level-1 descriptive coverage map**, not a paper/sample/condition-resolved matrix-family effect model. The publisher-XML identity corpus contains **78,683 terminal documents**; **33,769** are classified as titanium-alloy in scope, **1,827** as confirmed Ti-TMC and **4,258** as possible Ti-TMC. The older TiKB V11 inventory reports **55,437 records**, **5,537 unique papers**, and a highly imbalanced alloy distribution dominated by Ti-6Al-4V and TMC records.

The required Q40/V29 atomic table body and its row-level provenance were not available to this runtime. Therefore per-grade independent-paper counts, family baseline distributions, matrix-family random intercepts, reinforcement random slopes, tau-squared, I-squared, LOPO and same-condition matched effects are `NOT_IDENTIFIABLE`. No record count is presented as an independent-study count.

## Explicit estimands delivered

1. Publisher-XML scope fractions relative to 78,683 terminal XML objects.
2. TiKB V11 class and core-grade record coverage relative to 55,437 records.
3. Property availability in the 31,188-row ML-ready summary: UTS 17,153 rows (55.1%), YS 13,395 rows (43.0%), elongation 48.2% fill.
4. Grade-level **record-coverage support flags**. These are not effect-estimability claims.

## Claim ceiling

Only corpus coverage, summary-level missingness and taxonomy conflicts may be claimed. No alloy grade is claimed to cause a performance change. No Gold promotion, production-model registration, validated recipe or platform retraining is performed.

## Status

`CONTINUE_DATA_GAP`: the contract-complete recovery package, schemas, code, plots, tests, manifest and checksums are delivered; the authoritative Q40 atomic snapshot is still required for the requested hierarchical effect analysis.
