import hashlib, json, pathlib, zipfile
import pandas as pd
ROOT=pathlib.Path(__file__).resolve().parents[1]

def test_required_files():
    required=['00_EXECUTIVE_VERDICT.md','INPUT_LEDGER.csv','ANALYSIS_COHORT.csv','PAIR_MATCHES.csv','EFFECT_ESTIMATES.csv','HIERARCHICAL_RESULTS.csv','DOSE_RESPONSE.csv','INTERACTION_EFFECTS.csv','HETEROGENEITY.csv','SENSITIVITY_ANALYSIS.csv','NULL_NEGATIVE_RESULTS.csv','CONFLICT_LEDGER.csv','PROVENANCE.jsonl','METHODS.md','LIMITATIONS.md','PLOT_SPECS.json','WEB_TO_LOCAL_REQUEST.json','LOCAL_ABSORPTION_PROMPT.md','WINDOW_STATUS.json','MANIFEST.json','CHECKSUMS.sha256','MATRIX_TAXONOMY.csv','GRADE_ALIAS_REGISTRY.csv','COVERAGE_CUBE.parquet','ESTIMABILITY_MATRIX.csv']
    assert all((ROOT/x).exists() for x in required)

def test_status_and_claim_ceiling():
    s=json.loads((ROOT/'WINDOW_STATUS.json').read_text(encoding='utf-8'))
    assert s['window_id']=='QM01' and s['status']=='CONTINUE_DATA_GAP'
    assert s['claim_level_max']<=1 and not s['gold_promotion'] and not s['production_model_registration']

def test_no_row_as_paper_substitution():
    e=pd.read_csv(ROOT/'ESTIMABILITY_MATRIX.csv')
    assert (e['independent_papers']=='NOT_IDENTIFIABLE').all()

def test_empty_effect_outputs_are_schema_valid():
    assert len(pd.read_csv(ROOT/'PAIR_MATCHES.csv'))==0
    assert len(pd.read_csv(ROOT/'EFFECT_ESTIMATES.csv'))==0
    assert len(pd.read_csv(ROOT/'HIERARCHICAL_RESULTS.csv'))==0

def test_coverage_fractions():
    c=pd.read_csv(ROOT/'COVERAGE_ESTIMANDS.csv')
    assert ((c['estimate']>=0)&(c['estimate']<=1)).all()
    assert set(c['claim_level'])=={1}

def test_provenance_has_snapshot_and_hash():
    rows=[json.loads(x) for x in (ROOT/'PROVENANCE.jsonl').read_text(encoding='utf-8').splitlines() if x]
    assert rows and all(x['snapshot_id'] and x['source_hash'] for x in rows)

def test_checksums():
    for line in (ROOT/'CHECKSUMS.sha256').read_text(encoding='utf-8').splitlines():
        h,rel=line.split('  ',1)
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h
