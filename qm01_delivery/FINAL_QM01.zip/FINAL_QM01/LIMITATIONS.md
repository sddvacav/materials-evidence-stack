# Limitations

1. The authoritative Q40/V29 `ATOMIC_RECORDS` body was unavailable.
2. Per-grade paper counts, sample identities and condition identities are absent from the exposed summaries.
3. TiKB V11 reports contain snapshot-dependent totals (55,437/5,537 versus 49,148/4,837); both are retained in the conflict ledger.
4. Record counts measure coverage, not evidence independence or scientific quality.
5. Global unfiltered property means contain documented extreme outliers and are not used as family baselines.
6. The XW01 corpus provides document identity/scope, not sample-level mechanical performance.
7. No causal, validated-design or production-model claim is made.
