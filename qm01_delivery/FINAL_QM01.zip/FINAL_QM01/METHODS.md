# Methods

## Estimands

This recovery execution estimates corpus/document and database-record coverage only. Fractions use their own source-specific denominators and are never mixed across XW01 and TiKB V11.

## Taxonomy

A literature-grade alias registry maps labels to cp-Ti, near-alpha, alpha+beta, metastable-beta, beta and TMC families. Composition-driven verification is marked missing; ambiguous labels are retained rather than silently forced.

## Independence

The global TiKB V11 source reports 5,537 unique papers, but it does not expose a per-grade paper-identity table in the current runtime. Therefore grade-level record counts are not converted to effective study counts. Rows are not treated as independent studies.

## Effects and uncertainty

No matched effect, hierarchical model, tau-squared, I-squared, random slope, LOPO or prediction interval is fitted without authoritative paper/sample/condition-resolved atomic rows. Required empty-schema outputs are delivered with `NOT_IDENTIFIABLE` explanations.

## Figures

Figures are generated from `figure_data/*.csv` by deterministic matplotlib code. Required figures whose estimands are not identifiable show an explicit NI panel rather than fabricated distributions.
