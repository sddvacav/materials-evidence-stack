# Acceptance commands

```bash
python -m pip install pandas==2.2.3 pyarrow==18.1.0 pytest==8.3.4 matplotlib==3.9.2 numpy==2.1.3
python -m pytest -q tests/test_contract.py
python plot_code/plot_f1_sunburst.py
python plot_code/plot_f2_heatmap.py
python plot_code/plot_f3_ridgeline.py
python plot_code/plot_f4_traffic.py
```

Acceptance requires all tests PASS, checksum verification PASS, four figures reproducible, and `WINDOW_STATUS.status` preserved as `CONTINUE_DATA_GAP` until the authoritative atomic snapshot is restored.
