# Local absorption

1. Verify `FINAL_QM01.zip.sha256` and every entry in `CHECKSUMS.sha256`.
2. Inspect `WINDOW_STATUS.json`; this package is `CONTINUE_DATA_GAP`, not Gold or production-ready.
3. Supply the immutable Q40 atomic snapshot requested in `WEB_TO_LOCAL_REQUEST.json`.
4. Rerun the builder, then require paper-cluster matched effects, LOPO, evidence-grade sensitivity and plot regeneration before promotion.
5. Do not mutate ACTIVE_TITMC, Gold, unified Schema, split authority or production model registry from this recovery package.
