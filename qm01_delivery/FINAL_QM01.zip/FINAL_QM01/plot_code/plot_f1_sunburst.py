#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'figure_data'/'sunburst_data.csv'
OUT=ROOT/'figures'/'QM01_F1_sunburst_reproduced.png'
df=pd.read_csv(DATA)
fig,ax=plt.subplots(figsize=(10,6))
d=df.groupby(['matrix_family','alloy_grade'],as_index=False)['records'].sum(); ax.barh(d['alloy_grade'],d['records']); ax.set_title('Matrix family → grade record coverage'); ax.set_xlabel('records')
fig.tight_layout(); fig.savefig(OUT,dpi=600)
print(OUT)
