#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'figure_data'/'estimability_traffic_light_data.csv'
OUT=ROOT/'figures'/'QM01_F4_estimability_traffic_light_reproduced.png'
df=pd.read_csv(DATA)
fig,ax=plt.subplots(figsize=(10,6))
ax.barh(df['alloy_grade'],df['records']); ax.set_title('Record coverage; effect estimability blocked'); ax.set_xlabel('records')
fig.tight_layout(); fig.savefig(OUT,dpi=600)
print(OUT)
