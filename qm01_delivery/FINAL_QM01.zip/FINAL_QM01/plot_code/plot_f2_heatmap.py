#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'figure_data'/'coverage_heatmap_data.csv'
OUT=ROOT/'figures'/'QM01_F2_coverage_heatmap_reproduced.png'
df=pd.read_csv(DATA)
fig,ax=plt.subplots(figsize=(10,6))
ax.axis('off'); ax.text(0.5,0.5,'NOT IDENTIFIABLE\nAtomic family-property identities required',ha='center',va='center',transform=ax.transAxes)
fig.tight_layout(); fig.savefig(OUT,dpi=600)
print(OUT)
