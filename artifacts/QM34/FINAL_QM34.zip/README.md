# FINAL_QM34

Read-only quantitative return for thermal-expansion mismatch, GND/dislocation density and dislocation-strengthening contribution in titanium-matrix composites.

- Snapshot: `QM34_DERIVED_aab06def67414450b412` (derived recovery snapshot; canonical V29/Q40 snapshot absent)
- Independent papers used: 6
- Same-paper matched pairs: 10
- Quantitative figures: 4 × SVG/PDF/600-dpi PNG
- Claim ceiling: Level 2
- Status: CONTINUE_DATA_GAP

Start with `00_EXECUTIVE_VERDICT.md`. Reproduce with `analysis_code/recompute_qm34.py` and `plot_code/plot_all.py`. This package does not alter ACTIVE_TITMC, Gold, Schema or any production model registry.
