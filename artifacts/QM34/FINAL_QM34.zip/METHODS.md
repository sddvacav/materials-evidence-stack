# METHODS — QM34

## Estimands

1. Model or equivalent dislocation density, `rho_CTE/GND`.
2. `delta_sigma_dislocation = M alpha G b sqrt(rho)`.
3. Same-paper matched `delta YS` and the audited ratio `delta_sigma_CTE / delta YS`.
4. Constrained sensitivities to CTE mismatch, cooling interval, particle fraction/size, prefactor and retained-density fraction.

## Atomicity and matching

Rows remain paper × sample × process/condition × test mode × temperature × property. Ten A-grade within-paper matched control/TMC pairs are retained: four Liu tensile pairs and six Munir compression pairs. The three Zhao rows are theoretical parameter points and are never merged with measured pairs.

## CTE/GND equations

For the Zhao anchor:

`rho = B |delta_alpha| delta_T Vf / [(1-Vf) b d]`, with `B=6`.

`delta_sigma = alpha G b sqrt(rho)`.

The Jiang source uses a factor-12 form, but its symbol definition and numerical inputs do not close; it is retained as `NOT_IDENTIFIABLE`. Source-reported Liu/Munir strengthening terms are converted to an *equivalent* density using `rho_eq=(delta_sigma/(1.25 G b))^2`, `G=45 GPa`, and `b=0.289 nm`. Equivalent density is not a direct measurement.

## Uncertainty and temperature applicability

No source supplies a defensible sampling distribution for every formula input. Therefore statistical CIs and cross-paper prediction intervals are explicitly `NOT_IDENTIFIABLE`. Plotted bars use the declared physical scenario `f_retained=0.1–1.0`: `rho_eff=f rho`, `delta_sigma_eff=sqrt(f) delta_sigma`. They are not mislabeled as confidence intervals. High-temperature transfer is prohibited until `G(T)`, recovery, thermal cycling and stress-relaxation retention are available.

## Method calibration firewall

KAM/TEM/XRD are not pooled as interchangeable densities. The only numeric proxy check is the four-sample Liu KAM–source-term association (Pearson r=0.831; Spearman rho=0.800); it is process-confounded and cannot calibrate one method to another.

## Statistical decision

A universal hierarchical mechanism fraction is not fitted because there are only two matched-budget papers and the Munir budget fails internal closure. LOPO is reported as a stress test: Liu-only remains near one percent, while Munir-only is inadmissible. No BH-FDR family is formed because no confirmatory p-value family is estimated.

## Claim ceiling

Maximum level 2: same-paper matched association/source-calculation audit. No Gold promotion, ACTIVE mutation, production-model registration or VALIDATED formulation is performed.
