# QM34 Executive Verdict

`WINDOW=QM34 | SNAPSHOT=QM34_DERIVED_aab06def67414450b412 | INPUT_MODE=QUANT_EXECUTE/COHORT_BUILD`

## Terminal scientific answer

**CTE-mismatch/GND strengthening is real as a model term, but its attributed share is not transferable across Ti/TMC systems.** In the cleanest four matched CNT/Ti arms from Liu, source thermal-mismatch terms are only **2.7–5.3 MPa**, equivalent to **0.60–1.56%** of observed matched yield-strength gains; the within-paper median is **1.013%**. In the coarse TiB/Ti-6Al-4V Zhao model, 2–5 vol.% TiB gives `rho_CTE` approximately **2.32e+11–5.97e+11 m^-2** and `delta_sigma` approximately **5.95–9.55 MPa** under fixed RT constants.

The much larger Munir terms (**158.7–225.4 MPa**) do not survive a contribution-budget audit. Four of six point shares exceed 100%, and the 1.0 wt.%-Batch-2 specimen weakens by 85 MPa despite a positive 225.4 MPa thermal-mismatch term. Those rows are red-team evidence of circular/non-orthogonal budget closure, not estimates of a causal fraction.

Across the bound quantitative evidence, formula/equivalent densities span roughly **2.76e+10–1.92e+14 m^-2** and source/model strengthening terms span **2.7–225.4 MPa**. This four-order density range is driven by geometry, coefficient convention, dose, processing and residual-budget construction—not a universal Ti/TMC law.

## Measurement and service boundary

The four Liu KAM points show a descriptive Pearson r=0.831 and Spearman rho=0.800 versus the source CTE term, but all four points belong to one process-confounded paper. A KAM/TEM/XRD calibration is **NOT_IDENTIFIABLE**. High-temperature retained strengthening is also **NOT_IDENTIFIABLE** because recovery, stress relaxation, thermal cycling and `G(T)` are missing; the package reports a 10–100% retained-density scenario envelope instead of a false CI.

## Contribution answer

- Liu CNT/Ti matched evidence: about **0.6–1.6%** of observed matched delta YS by the source CTE term.
- Zhao coarse TiB/Ti-6Al-4V theory: about **6–10 MPa**, with no closed matched delta YS in the bound parameter record.
- Geng TiB/Ti-55531: source treats thermal mismatch as negligible; numeric contribution remains `NOT_IDENTIFIABLE`.
- Munir MWCNT/Ti: source terms are large but fail closure; contribution shares are inadmissible.
- Universal pooled fraction, random-effect coefficient and new-paper prediction interval: **NOT_IDENTIFIABLE**.

## Claim ceiling

Maximum claim level **2 — same-paper paired association/source-calculation audit**. CTE formulas are model estimates, not direct dislocation-density measurements. No Gold promotion, ACTIVE mutation, production-model registration or VALIDATED composition is claimed.

## Operational status

`CONTINUE_DATA_GAP`: the read-only derived package is complete and reproducible for the bound evidence, but authority absorption requires the canonical V29/Q40 atom/provenance snapshot, original byte hashes/XPaths, and direct same-sample KAM/TEM/XRD plus temperature-retention data.
