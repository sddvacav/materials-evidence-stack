# Acceptance commands

```bash
python analysis_code/recompute_qm34.py .
python tests/test_qm34_outputs.py .
python plot_code/plot_all.py .
sha256sum -c CHECKSUMS.sha256
python -c "import zipfile; z=zipfile.ZipFile('../FINAL_QM34.zip'); assert z.testzip() is None; assert not [n for n in z.namelist() if n.lower().endswith('.zip')]"
```
