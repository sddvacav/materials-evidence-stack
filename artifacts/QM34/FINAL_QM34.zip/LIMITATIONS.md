# LIMITATIONS — QM34

- The canonical V29/Q40 `ATOMIC_RECORDS`, provenance, conflicts, exclusions and paper/sample/condition registry are absent; this is a derived recovery snapshot.
- Original publication byte hashes/XPaths are not closed for the six target papers. Every numeric row is instead bound to a normalized evidence-capture SHA-256 and an explicit source locator.
- CTE formulas estimate an idealized density generated during cooling. They do not directly measure retained GND, do not separate GND from SSD, and do not represent recovery or stress relaxation at service temperature.
- The Zhao calculation assumes fixed mean particle diameter and isotropic scalar mismatch. Architecture, aspect-ratio distribution, local elastic anisotropy and interface constraint are suppressed.
- The Liu KAM association has n=4 in one paper and is confounded by powder treatment and consolidation route. It is not a KAM-to-rho calibration.
- The Munir budget is internally inconsistent for contribution attribution; it is retained only as a counterexample.
- Hall-Petch, processing work hardening, residual stress, load transfer and Orowan terms are not guaranteed orthogonal. Additive summation can double count stored dislocations and refinement effects.
- Cross-paper CIs, prediction intervals, random slopes, FDR-adjusted interactions and a universal contribution fraction are not identifiable.
