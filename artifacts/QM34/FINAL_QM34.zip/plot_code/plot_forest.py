#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root = Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve()
raise SystemExit(subprocess.call([sys.executable, str(Path(__file__).with_name("plot_all.py")), str(root), "--only", "forest"]))
