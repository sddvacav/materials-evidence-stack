# LOCAL ABSORPTION PROMPT — QM34

1. Verify `FINAL_QM34.zip` SHA-256 and `testzip`; reject nested ZIPs.
2. Extract into a quarantine directory. Run `sha256sum -c CHECKSUMS.sha256` and `python tests/test_qm34_outputs.py .`.
3. Run `python analysis_code/recompute_qm34.py .` and require byte-identical `RECOMPUTE_OUTPUT.txt` with status PASS.
4. Resolve `WEB_TO_LOCAL_REQUEST.json`; map all derived paper/sample/condition UIDs to the unique canonical V29/Q40 snapshot.
5. Re-run formula rows using original-byte/XPath-bound parameters and compare against `CTE_GND_INPUTS.csv`.
6. Do not mutate ACTIVE_TITMC, Gold, Schema or production model registries. Promote only after independent provenance, conflict, unit, double-count and method-calibration review.

Expected snapshot from this package: `QM34_DERIVED_aab06def67414450b412`.
