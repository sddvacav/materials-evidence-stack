# Platform Dimension Claim

|Dimension|This return|Verification|
|---|---|---|
|Safety|malformed/missing UQ fails closed; no point-only fallback|pressure/unit tests|
|Accuracy honesty|PICP/width/interval-score reporter; GE5 != HQ-LOSO|coverage audit/tests|
|Scientific correctness|nonnegative, trained range, YS<=UTS, tail state|L4 tests|
|Maintainability|stdlib-only, additive, external policy|compile/SHA/patch check|
|UI clarity|Chinese card with interval, reasons, analogs, actions, boundary|schema/smoke|

No empirical metric/FULLSCORE improvement is claimed.
