# G06 Method IR — UQ · OOD · AD · Reject Recommendation

## Scope
Additive gate for titanium alloys/TMCs. It consumes an existing prediction,
current ClaimEnvelope uncertainty fields, materials-data-firewall status,
protocol receipts, nearest analogs, and tail-trust. It does not train/promote.

## Conformal kernel
`s_i = |y_i-yhat_i| / max(scale_i, eps)` and
`qhat = score_(ceil((n+1)(1-alpha)))`, capped at rank `n`.
Interval: `[yhat-qhat*scale, yhat+qhat*scale]`.

## Mondrian hierarchy
`exact -> target_family_route -> target_family -> target -> global`.
Underpowered groups fall back; no small-group qhat is emitted.

## Leakage boundary
Held-out study/source cannot enter training, preprocessing, AD threshold fitting,
or calibration. `LeakageError` is raised before qhat fitting.

## Four layers
L1 schema/unit/firewall; L2 frozen Track-S AD/OOD; L3 UQ/calibration/protocol;
L4 tail-trust/physics. Fusion: `severity_final=max(L1,L2,L3,L4)`.

## Diagnostics
PICP, Wilson95, mean width, mean interval score. Wilson is diagnostic, not a
conformal/source-holdout guarantee.

## Claim boundary
GE5 is not LOSO. No HQ-LOSO => no FULLSCORE/production/publication-default.
