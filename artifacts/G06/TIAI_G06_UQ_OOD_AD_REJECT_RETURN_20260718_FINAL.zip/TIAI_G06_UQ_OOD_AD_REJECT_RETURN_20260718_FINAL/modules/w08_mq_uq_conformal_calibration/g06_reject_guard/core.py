from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field
from enum import Enum, IntEnum
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


class Severity(IntEnum):
    PASS = 0
    WARN = 1
    REJECT = 2


class Decision(str, Enum):
    ACCEPT = "ACCEPT"
    WARN = "WARN"
    REJECT = "REJECT"


class LeakageError(RuntimeError):
    pass


class PolicyError(ValueError):
    pass


@dataclass(frozen=True)
class GroupKey:
    target: str
    material_family: str = "UNKNOWN"
    process_route: str = "UNKNOWN"
    temperature_bin: str = "UNKNOWN"

    def key(self, level: str) -> tuple[str, ...]:
        if level == "exact":
            return self.target, self.material_family, self.process_route, self.temperature_bin
        if level == "target_family_route":
            return self.target, self.material_family, self.process_route
        if level == "target_family":
            return self.target, self.material_family
        if level == "target":
            return (self.target,)
        if level == "global":
            return ("GLOBAL",)
        raise ValueError(f"unknown level: {level}")


@dataclass(frozen=True)
class CalibrationRecord:
    y_true: float
    y_pred: float
    group: GroupKey
    source_id: str
    scale: float = 1.0
    split_role: str = "calibration"


@dataclass(frozen=True)
class Finding:
    layer: str
    code: str
    severity: Severity
    message_cn: str
    evidence: dict[str, Any] = field(default_factory=dict)
    close_action_cn: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["severity"] = self.severity.name
        return data


@dataclass(frozen=True)
class GateResult:
    decision: Decision
    findings: tuple[Finding, ...]
    machine_labels: dict[str, Any]
    claim_interval: dict[str, Any] | None
    nearest_analogs: tuple[dict[str, Any], ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "tiai.g06.uq-ood-ad-decision.v1",
            "decision": self.decision.value,
            "findings": [x.to_dict() for x in self.findings],
            "machine_labels": self.machine_labels,
            "claim_interval": self.claim_interval,
            "nearest_analogs": list(self.nearest_analogs),
        }


def load_policy(path: str | Path) -> dict[str, Any]:
    try:
        policy = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PolicyError("policy must be JSON-compatible YAML") from exc
    required = {"nominal_coverage", "alpha", "mondrian", "ad", "interval", "claim_gate"}
    missing = sorted(required - set(policy))
    if missing:
        raise PolicyError(f"missing policy sections: {missing}")
    coverage, alpha = float(policy["nominal_coverage"]), float(policy["alpha"])
    if not (0 < coverage < 1 and 0 < alpha < 1 and abs(coverage - (1 - alpha)) < 1e-12):
        raise PolicyError("coverage/alpha contract invalid")
    order = policy["mondrian"].get("fallback_order")
    approved = ["exact", "target_family_route", "target_family", "target", "global"]
    if order != approved:
        raise PolicyError("unapproved Mondrian fallback order")
    return policy


def finite_sample_quantile(scores: Sequence[float], alpha: float) -> float:
    values = sorted(float(x) for x in scores if math.isfinite(float(x)))
    if not values or not 0 < alpha < 1:
        raise ValueError("finite scores and alpha in (0,1) required")
    rank = min(len(values), max(1, math.ceil((len(values) + 1) * (1 - alpha))))
    return values[rank - 1]


class MondrianCalibrator:
    LEVELS = ("exact", "target_family_route", "target_family", "target", "global")

    def __init__(self, policy: Mapping[str, Any]) -> None:
        self.alpha = float(policy["alpha"])
        self.minimum_n = {k: int(v) for k, v in policy["mondrian"]["minimum_calibration_n"].items()}
        self.scale_floor = float(policy["interval"].get("scale_floor", 1e-9))
        self.pools: dict[tuple[str, tuple[str, ...]], list[float]] = {}

    def fit(self, records: Iterable[CalibrationRecord], held_out_source_ids: Iterable[str] = ()) -> "MondrianCalibrator":
        held = {str(x) for x in held_out_source_ids}
        n = 0
        for record in records:
            if record.split_role != "calibration":
                continue
            if record.source_id in held:
                raise LeakageError(f"held-out source entered calibration: {record.source_id}")
            score = abs(float(record.y_true) - float(record.y_pred)) / max(abs(float(record.scale)), self.scale_floor)
            for level in self.LEVELS:
                self.pools.setdefault((level, record.group.key(level)), []).append(score)
            n += 1
        if n == 0:
            raise ValueError("no calibration records")
        return self

    def interval(
        self,
        point: float,
        scale: float,
        group: GroupKey,
        physical_min: float | None = None,
        physical_max: float | None = None,
    ) -> dict[str, Any]:
        for depth, level in enumerate(self.LEVELS):
            scores = self.pools.get((level, group.key(level)), [])
            if len(scores) < self.minimum_n[level]:
                continue
            qhat = finite_sample_quantile(scores, self.alpha)
            radius = qhat * max(abs(float(scale)), self.scale_floor)
            lo, hi = float(point) - radius, float(point) + radius
            if physical_min is not None:
                lo = max(lo, float(physical_min))
            if physical_max is not None:
                hi = min(hi, float(physical_max))
            if lo > hi:
                return {"ok": False, "reason": "EMPTY_AFTER_PHYSICAL_INTERSECTION"}
            return {
                "ok": True, "interval": [lo, hi], "conformal_qhat": qhat,
                "qhat_scope": level, "calibration_n": len(scores), "fallback_depth": depth,
            }
        return {"ok": False, "reason": "INSUFFICIENT_CALIBRATION_SUPPORT"}


def _wilson(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    p = successes / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def coverage_audit(y_true: Sequence[float], intervals: Sequence[Sequence[float]], alpha: float) -> dict[str, Any]:
    if not y_true or len(y_true) != len(intervals):
        raise ValueError("equal non-empty inputs required")
    hits, widths, scores = 0, [], []
    for y, bounds in zip(y_true, intervals):
        lo, hi = map(float, bounds)
        if lo > hi:
            raise ValueError("unordered interval")
        hits += int(lo <= y <= hi)
        width = hi - lo
        widths.append(width)
        penalty = (2 / alpha) * (lo - y) if y < lo else (2 / alpha) * (y - hi) if y > hi else 0
        scores.append(width + penalty)
    wlo, whi = _wilson(hits, len(y_true))
    return {
        "n": len(y_true), "covered_n": hits, "picp": hits / len(y_true),
        "nominal_coverage": 1 - alpha, "wilson95": [wlo, whi],
        "mean_width": sum(widths) / len(widths),
        "mean_interval_score": sum(scores) / len(scores),
    }


def _num(value: Any) -> float | None:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def adapt_claim_uncertainty(value: Mapping[str, Any]) -> dict[str, Any]:
    required = [
        "method", "nominal_coverage", "interval", "conformal_qhat", "qhat_scope",
        "ad_distance_mean10", "ad_threshold_q95",
    ]
    missing = [k for k in required if k not in value]
    if missing:
        raise ValueError(f"missing uncertainty fields: {missing}")
    interval = value["interval"]
    if not isinstance(interval, (list, tuple)) or len(interval) != 2:
        raise ValueError("interval requires two bounds")
    lo, hi = _num(interval[0]), _num(interval[1])
    coverage, qhat = _num(value["nominal_coverage"]), _num(value["conformal_qhat"])
    distance, threshold = _num(value["ad_distance_mean10"]), _num(value["ad_threshold_q95"])
    if any(x is None for x in (lo, hi, coverage, qhat, distance, threshold)) or lo > hi:
        raise ValueError("uncertainty numbers invalid")
    return {
        "method": str(value["method"]), "nominal_coverage": coverage, "interval": [lo, hi],
        "conformal_qhat": qhat, "qhat_scope": str(value["qhat_scope"] or "").strip(),
        "ad_distance_mean10": distance, "ad_threshold_q95": threshold,
    }


def evaluate_request(payload: Mapping[str, Any], policy: Mapping[str, Any]) -> GateResult:
    findings: list[Finding] = []

    def add(layer: str, code: str, severity: Severity, message: str, evidence: Mapping[str, Any] | None = None, close: str | None = None) -> None:
        findings.append(Finding(layer, code, severity, message, dict(evidence or {}), close))

    target = str(payload.get("target") or "UNKNOWN").strip()
    unit = str(payload.get("unit") or "").strip()
    point = _num(payload.get("point"))
    integrity = payload.get("input_integrity") if isinstance(payload.get("input_integrity"), Mapping) else {}
    firewall = str(integrity.get("firewall_status") or "UNKNOWN").upper()
    if firewall != "PASS":
        add("L1_INPUT_FIREWALL", "FIREWALL_NOT_PASS", Severity.REJECT, "材料数据防火墙未通过，禁止推荐。", {"firewall_status": firewall})
    if not bool(integrity.get("schema_valid", False)):
        add("L1_INPUT_FIREWALL", "SCHEMA_INVALID", Severity.REJECT, "输入 schema 未验证。")
    if not bool(integrity.get("units_valid", False)) or not unit:
        add("L1_INPUT_FIREWALL", "UNIT_INVALID", Severity.REJECT, "目标单位缺失或无效。")
    missing_features = list(integrity.get("missing_features") or [])
    range_violations = list(integrity.get("range_violations") or [])
    if missing_features:
        add("L1_INPUT_FIREWALL", "MISSING_FROZEN_SCHEMA_FEATURES", Severity.REJECT, "冻结特征缺失。", {"missing_features": missing_features})
    if range_violations:
        add("L1_INPUT_FIREWALL", "FEATURE_RANGE_VIOLATION", Severity.REJECT, "输入超出冻结包络。", {"range_violations": range_violations})
    if str(integrity.get("material_class") or "").upper() == "TMC" and not bool(integrity.get("reinforcement_fields_complete", False)):
        add("L1_INPUT_FIREWALL", "TMC_REINFORCEMENT_FIELDS_INCOMPLETE", Severity.REJECT, "TMC 增强体字段不完整。")

    uncertainty = None
    try:
        if not isinstance(payload.get("uncertainty"), Mapping):
            raise ValueError("uncertainty must be an object")
        uncertainty = adapt_claim_uncertainty(payload["uncertainty"])
    except ValueError as exc:
        add("L2_AD_OOD", "UNCERTAINTY_CONTRACT_INVALID", Severity.REJECT, "UQ/AD 合同缺失或畸形，fail-closed。", {"error": str(exc)})

    ad_state, ad_ratio = "UNKNOWN", None
    if uncertainty:
        distance, threshold = uncertainty["ad_distance_mean10"], uncertainty["ad_threshold_q95"]
        if threshold <= 0 or distance < 0:
            add("L2_AD_OOD", "AD_METRIC_INVALID", Severity.REJECT, "AD 距离或阈值无效。")
        else:
            ad_ratio = distance / threshold
            if ad_ratio >= float(policy["ad"]["distance_ratio_reject"]):
                ad_state = "OUTSIDE"
                add("L2_AD_OOD", "OUTSIDE_APPLICABILITY_DOMAIN", Severity.REJECT, "候选位于适用域外，禁止推荐。", {"distance_ratio": ad_ratio}, "补充相邻 HQ 数据或转入 Track C。")
            elif ad_ratio >= float(policy["ad"]["distance_ratio_warn"]):
                ad_state = "BORDERLINE"
                add("L2_AD_OOD", "AD_BORDERLINE", Severity.WARN, "候选接近适用域边界，仅人工复核。", {"distance_ratio": ad_ratio})
            else:
                ad_state = "INSIDE"
        knn = _num(payload.get("knn_distance_percentile"))
        if knn is not None and knn >= float(policy["ad"]["knn_percentile_reject"]):
            add("L2_AD_OOD", "KNN_SUPPORT_OUTSIDE", Severity.REJECT, "近邻支持达到拒绝分位。")
        elif knn is not None and knn >= float(policy["ad"]["knn_percentile_warn"]):
            add("L2_AD_OOD", "KNN_SUPPORT_SPARSE", Severity.WARN, "近邻支持稀疏。")

    evidence = payload.get("claim_evidence") if isinstance(payload.get("claim_evidence"), Mapping) else {}
    caliber = str(evidence.get("caliber") or "UNVERIFIED").upper()
    hq_ref = str(evidence.get("hq_loso_receipt_ref") or "").strip()
    ge5_ref = str(evidence.get("ge5_receipt_ref") or "").strip()
    split_ref = str(evidence.get("split_manifest_ref") or "").strip()
    eval_refs = [str(x).strip() for x in evidence.get("evaluation_receipt_refs", []) if str(x).strip()]
    calibration_n = int(evidence.get("calibration_n") or 0)
    requested = str(evidence.get("requested_claim_level") or "EXPLORATORY").upper()
    allowed_calibers = {
        "UNVERIFIED", "CELL_KFOLD", "COND_GROUP_GE5", "ROUTE_LOSO", "FULL_LOSO",
        "TIME_SPLIT", "FAMILY_HOLDOUT", "PROCESS_HOLDOUT", "TEMPERATURE_HOLDOUT",
        "EXPERIMENTAL_VALIDATION",
    }
    if caliber not in allowed_calibers:
        caliber = "UNVERIFIED"
        add("L3_CALIBRATION_PROTOCOL", "CLAIM_CALIBER_UNKNOWN", Severity.REJECT, "评估口径枚举无效。")
    if caliber == "UNVERIFIED":
        add("L3_CALIBRATION_PROTOCOL", "CLAIM_CALIBER_UNVERIFIED", Severity.REJECT, "评估协议未验证。")
    if not split_ref or not eval_refs:
        add("L3_CALIBRATION_PROTOCOL", "PROTOCOL_RECEIPT_MISSING", Severity.REJECT, "split/evaluation 收据缺失。")
    if uncertainty:
        if uncertainty["method"] not in policy["claim_gate"]["allowed_uq_methods"]:
            add("L3_CALIBRATION_PROTOCOL", "UQ_METHOD_NOT_ALLOWLISTED", Severity.REJECT, "UQ 方法未在 allowlist。")
        if uncertainty["nominal_coverage"] < float(policy["nominal_coverage"]):
            add("L3_CALIBRATION_PROTOCOL", "COVERAGE_TARGET_DOWNGRADED", Severity.REJECT, "名义覆盖率低于政策目标。")
        if uncertainty["conformal_qhat"] < 0 or not uncertainty["qhat_scope"]:
            add("L3_CALIBRATION_PROTOCOL", "QHAT_INVALID", Severity.REJECT, "qhat 或 scope 无效。")
        scope = uncertainty["qhat_scope"]
        required_n = int(policy["mondrian"]["minimum_calibration_n"].get(scope, 10**9))
        if calibration_n < required_n:
            add("L3_CALIBRATION_PROTOCOL", "INSUFFICIENT_CALIBRATION_SUPPORT", Severity.REJECT, "分层校准样本量不足。", {"scope": scope, "calibration_n": calibration_n, "required_n": required_n})
    if caliber in {"ROUTE_LOSO", "FULL_LOSO"} and not hq_ref:
        add("L3_CALIBRATION_PROTOCOL", "HQ_LOSO_RECEIPT_ABSENT", Severity.REJECT, "声明 LOSO 但 HQ-LOSO 收据缺失。")
    elif not hq_ref:
        add("L3_CALIBRATION_PROTOCOL", "HQ_LOSO_NOT_CLOSED", Severity.WARN, "无 HQ-LOSO，只允许内部/探索使用。")
    if ge5_ref and caliber not in {"COND_GROUP_GE5", "UNVERIFIED"} and not hq_ref:
        add("L3_CALIBRATION_PROTOCOL", "GE5_CANNOT_UPGRADE_TO_LOSO", Severity.REJECT, "GE5 不能升级为 LOSO。")
    if requested in {"FULLSCORE", "PRODUCTION_CHAMPION", "PUBLICATION_DEFAULT"} and not hq_ref:
        add("L3_CALIBRATION_PROTOCOL", "REQUESTED_CLAIM_EXCEEDS_EVIDENCE", Severity.REJECT, "请求主张超过证据上限。")

    tail = payload.get("tail_trust") if isinstance(payload.get("tail_trust"), Mapping) else {}
    tail_state = str(tail.get("state") or "UNKNOWN").upper()
    if tail_state == "TAIL_CANDIDATE":
        add("L4_OUTPUT_TAIL_PHYSICS", "TAIL_CANDIDATE", Severity.WARN, "稀有候选仅允许 tail review。")
    elif tail_state in {"UNSUPPORTED_EXTREME", "BELOW_GATE", "UNKNOWN"}:
        add("L4_OUTPUT_TAIL_PHYSICS", f"TAIL_{tail_state}", Severity.REJECT, "tail-trust 未通过。")
    elif tail_state != "VALIDATED":
        add("L4_OUTPUT_TAIL_PHYSICS", "TAIL_STATE_INVALID", Severity.REJECT, "tail-trust 状态无效。")

    claim_interval = None
    if point is None:
        add("L4_OUTPUT_TAIL_PHYSICS", "POINT_PREDICTION_INVALID", Severity.REJECT, "点估计非有限数。")
    elif uncertainty:
        lo, hi = uncertainty["interval"]
        nonnegative = {str(x).lower() for x in policy["interval"]["nonnegative_targets"]}
        if target.lower() in nonnegative and lo < 0:
            add("L4_OUTPUT_TAIL_PHYSICS", "NEGATIVE_LOWER_BOUND", Severity.REJECT, "非负性质出现负区间下界。")
        trained_min, trained_max = _num(payload.get("trained_label_min")), _num(payload.get("trained_label_max"))
        if trained_min is None or trained_max is None or trained_min > trained_max:
            add("L4_OUTPUT_TAIL_PHYSICS", "TRAINED_RANGE_MISSING", Severity.REJECT, "冻结训练标签范围缺失。")
        elif not trained_min <= point <= trained_max:
            add("L4_OUTPUT_TAIL_PHYSICS", "TARGET_OUTSIDE_TRAINED_RANGE", Severity.REJECT, "点估计超出训练标签范围。")
        ratio = (hi - lo) / max(abs(point), float(policy["interval"]["width_ratio_floor"]))
        if ratio >= float(policy["interval"]["width_ratio_reject"]):
            add("L4_OUTPUT_TAIL_PHYSICS", "INTERVAL_TOO_WIDE", Severity.REJECT, "区间过宽。")
        elif ratio >= float(policy["interval"]["width_ratio_warn"]):
            add("L4_OUTPUT_TAIL_PHYSICS", "INTERVAL_WIDE", Severity.WARN, "区间较宽。")
        companion_uts = _num(payload.get("companion_uts_mpa"))
        if target.lower() in {"ys_mpa", "yield_strength_mpa"} and companion_uts is not None and point > companion_uts:
            add("L4_OUTPUT_TAIL_PHYSICS", "YS_EXCEEDS_UTS", Severity.REJECT, "YS 高于 UTS，违反力学顺序。")
        claim_interval = {
            "target": target, "unit": unit, "point": point, **uncertainty,
            "coverage_semantics_cn": "覆盖率仅对声明的校准/评估口径成立，不自动外推到新来源。",
        }

    max_severity = max((x.severity for x in findings), default=Severity.PASS)
    decision = Decision.REJECT if max_severity == Severity.REJECT else Decision.WARN if max_severity == Severity.WARN else Decision.ACCEPT
    fullscore_row = bool(
        decision == Decision.ACCEPT and hq_ref and caliber in {"ROUTE_LOSO", "FULL_LOSO"}
        and tail_state == "VALIDATED" and ad_state == "INSIDE" and firewall == "PASS"
    )
    labels = {
        "firewall_status": firewall,
        "ad_state": ad_state,
        "ad_distance_ratio": ad_ratio,
        "calibration_scope": uncertainty.get("qhat_scope") if uncertainty else None,
        "calibration_n": calibration_n,
        "tail_trust_state": tail_state,
        "claim_caliber": caliber,
        "ge5_receipt_present": bool(ge5_ref),
        "hq_loso_receipt_present": bool(hq_ref),
        "recommendation_state": decision.value,
        "claim_state": "SUPPORTED_INTERVAL" if decision == Decision.ACCEPT else "WARN_INTERVAL" if decision == Decision.WARN else "REJECT_RECOMMENDATION",
        "fullscore_eligible_for_this_row": fullscore_row,
        "platform_fullscore_claimed": False,
        "triggered_codes": [x.code for x in findings],
    }
    nearest = tuple(dict(x) for x in payload.get("nearest_analogs", []) if isinstance(x, Mapping))
    return GateResult(decision, tuple(findings), labels, claim_interval, nearest)


def build_reject_card(result: GateResult, candidate_id: str, trace_id: str) -> dict[str, Any]:
    title = {
        "ACCEPT": "区间证据通过本窗门禁",
        "WARN": "仅限人工复核，不自动推荐",
        "REJECT": "拒绝推荐：证据或适用域未闭合",
    }[result.decision.value]
    actions = [x.close_action_cn for x in result.findings if x.close_action_cn]
    return {
        "schema": "tiai.g06.reject-card.v1",
        "candidate_id": candidate_id,
        "trace_id": trace_id,
        "status": result.decision.value,
        "title_cn": title,
        "summary_cn": "材料数据防火墙、AD/OOD、校准协议、tail-trust/物理一致性四层联合判定。",
        "claim_interval": result.claim_interval,
        "reason_cards": [x.to_dict() for x in result.findings],
        "nearest_analogs": list(result.nearest_analogs),
        "machine_labels": result.machine_labels,
        "dual_caliber": {
            "ge5": {"receipt_present": result.machine_labels["ge5_receipt_present"], "meaning_cn": "GE5 不是 LOSO。"},
            "hq_loso": {"receipt_present": result.machine_labels["hq_loso_receipt_present"], "meaning_cn": "缺失时禁止 FULLSCORE。"},
        },
        "close_actions_cn": list(dict.fromkeys(actions)),
        "claim_boundary_cn": "本卡只做门禁，不训练、不晋级、不宣称平台 FULLSCORE。",
    }
