"""Fail-closed G06 UQ/OOD/AD recommendation guard."""

from .core import (
    CalibrationRecord,
    Decision,
    GateResult,
    GroupKey,
    LeakageError,
    MondrianCalibrator,
    adapt_claim_uncertainty,
    build_reject_card,
    coverage_audit,
    evaluate_request,
    finite_sample_quantile,
    load_policy,
)

__all__ = [
    "CalibrationRecord", "Decision", "GateResult", "GroupKey", "LeakageError",
    "MondrianCalibrator", "adapt_claim_uncertainty", "build_reject_card",
    "coverage_audit", "evaluate_request", "finite_sample_quantile", "load_policy",
]
