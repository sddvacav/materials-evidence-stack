from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from .core import build_reject_card, evaluate_request, load_policy

def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--policy", required=True)
    p.add_argument("--input", required=True)
    a = p.parse_args(argv)
    try:
        policy = load_policy(a.policy)
        payload = json.loads(Path(a.input).read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("input root must be object")
        result = evaluate_request(payload, policy)
        card = build_reject_card(result, str(payload.get("candidate_id") or "UNKNOWN"), str(payload.get("trace_id") or "UNKNOWN"))
        print(json.dumps(card, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result.decision.value != "REJECT" else 2
    except Exception as exc:
        print(json.dumps({"schema":"tiai.g06.reject-card.v1","status":"REJECT","title_cn":"拒绝推荐：输入无法验证","error":f"{type(exc).__name__}: {exc}","claim_boundary_cn":"异常路径不得回退到无 UQ 点预测。"}, ensure_ascii=False, indent=2))
        return 2

if __name__ == "__main__":
    sys.exit(main())
