# G06 Reject Guard

Additive, standard-library-only adapter for the current Track-S/ClaimEnvelope
contracts. Four fail-closed layers: input firewall, AD/OOD, calibration/protocol,
tail-trust/physics. It does not train, promote, clamp, or silently impute a model.
