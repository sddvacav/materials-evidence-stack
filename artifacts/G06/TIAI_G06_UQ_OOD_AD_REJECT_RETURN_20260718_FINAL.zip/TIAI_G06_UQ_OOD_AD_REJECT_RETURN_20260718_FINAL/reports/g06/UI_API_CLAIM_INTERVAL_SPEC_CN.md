# UI/API 区间与拒绝卡规格

ACCEPT/WARN/REJECT 三态。必须显示 target/unit/point/90% PI、qhat scope、
calibration_n、AD distance/threshold、firewall、tail-trust、GE5/HQ-LOSO
双列、nearest analog、reason codes、close actions、claim boundary。

禁止：分数自动升级口径；GE5 改写为 LOSO；缺 UQ 回退裸点预测；
无覆盖复核的物理裁剪；删除 unsupported extreme。
