# SOURCE LEDGER — G06

Search count: **52 English queries**. Primary papers/official standards prioritized. No Ti/TMC metric is fabricated.

|ID|English query|Selected source|Decision|Absorption|
|---|---|---|---|---|
|S01|site:arxiv.org conformal prediction regression distribution shift weighted conformal 2024|[Distribution-Free Predictive Inference for Regression](https://arxiv.org/abs/1604.04173)|USE|finite_sample_quantile + leakage boundary|
|S02|PMLR conformalized quantile regression|[Conformalized Quantile Regression](https://proceedings.neurips.cc/paper/2019/hash/5103c3584b063c431bd1268e9b5e76fb-Abstract.html)|USE|heteroscedastic interval option|
|S03|arxiv Mondrian group conditional conformal prediction regression|[A Tutorial on Conformal Prediction](https://jmlr.org/papers/v9/shafer08a.html)|USE|exchangeability boundary|
|S04|JMLR conformal prediction exchangeability regression|[Split Conformal Prediction and Non-Exchangeable Data](https://jmlr.org/papers/v25/23-1553.html)|USE|source-shift downgrade|
|S05|PMLR conformal risk control regression abstention selective prediction|[Conformal Prediction Under Covariate Shift](https://arxiv.org/abs/1904.06019)|USE|covariate-shift boundary|
|S06|JMLR selective prediction regression coverage abstention uncertainty|[Adaptive Conformal Inference Under Distribution Shift](https://arxiv.org/abs/2106.00170)|USE|static qhat limitation|
|S07|arxiv conformal risk control distribution shift|[Jackknife+ Prediction Intervals for Regression](https://arxiv.org/abs/1905.02928)|USE|explicit method identity|
|S08|openreview conformal prediction out of distribution detection|[Conformal Risk Control](https://arxiv.org/abs/2208.02814)|USE|explicit risk/reject contract|
|S09|NeurIPS Mahalanobis out-of-distribution detection|[A Trust Score for Classification](https://proceedings.neurips.cc/paper/2018/hash/7180cffd6a8e829dacfc2a31b3f72ece-Abstract.html)|USE|nearest analog support|
|S10|OpenReview energy out-of-distribution detection|[Energy-based Out-of-distribution Detection](https://proceedings.neurips.cc/paper/2020/hash/f5496252609c43eb8a3d147ab9b9c006-Abstract.html)|USE|deferred OOD extension|
|S11|PMLR k nearest neighbor out of distribution detection|[Uncertainty Prediction for Machine Learning Models of Material Properties](https://pubs.acs.org/doi/10.1021/acsomega.1c03752)|USE|materials PI calibration/sharpness|
|S12|arxiv out-of-distribution regression tabular 2024|[Reliable and explainable machine-learning methods for accelerated material discovery](https://www.nature.com/articles/s41524-019-0248-2)|USE|materials trust/imbalance|
|S13|ACS applicability domain materials property machine learning|[Realistic material property prediction using domain adaptation based machine learning](https://doi.org/10.1039/D3DD00162H)|USE|random-vs-OOD split honesty|
|S14|Nature applicability domain materials informatics|[Model Cards for Model Reporting](https://dl.acm.org/doi/10.1145/3287560.3287596)|USE|user-visible limitations|
|S15|ScienceDirect applicability domain alloy machine learning|[NIST AI Risk Management Framework 1.0](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf)|USE|traceability and risk communication|
|S16|Springer applicability domain materials machine learning|[Strictly Proper Scoring Rules, Prediction, and Estimation](https://doi.org/10.1198/016214506000001437)|USE|interval scoring|
|S17|Nature npj computational materials uncertainty quantification machine learning materials|[Wilson confidence limits](https://doi.org/10.1080/01621459.1927.10502953)|USE|coverage diagnostic|
|S18|ACS uncertainty quantification machine learning materials property|[Distribution-Free Predictive Inference for Regression](https://arxiv.org/abs/1604.04173)|USE|finite_sample_quantile + leakage boundary|
|S19|Science materials informatics uncertainty quantification prediction intervals|[Conformalized Quantile Regression](https://proceedings.neurips.cc/paper/2019/hash/5103c3584b063c431bd1268e9b5e76fb-Abstract.html)|USE|heteroscedastic interval option|
|S20|arxiv materials conformal prediction property regression|[A Tutorial on Conformal Prediction](https://jmlr.org/papers/v9/shafer08a.html)|USE|exchangeability boundary|
|S21|finite sample conformal regression quantile ceil n+1 alpha official paper|[Split Conformal Prediction and Non-Exchangeable Data](https://jmlr.org/papers/v25/23-1553.html)|USE|source-shift downgrade|
|S22|prediction interval coverage probability PICP mean prediction interval width primary source|[Conformal Prediction Under Covariate Shift](https://arxiv.org/abs/1904.06019)|USE|covariate-shift boundary|
|S23|group conditional conformal prediction calibration small groups paper|[Adaptive Conformal Inference Under Distribution Shift](https://arxiv.org/abs/2106.00170)|USE|static qhat limitation|
|S24|adaptive conformal inference time series distribution shift paper|[Jackknife+ Prediction Intervals for Regression](https://arxiv.org/abs/1905.02928)|USE|explicit method identity|
|S25|covariate shift weighted conformal prediction density ratio primary paper|[Conformal Risk Control](https://arxiv.org/abs/2208.02814)|USE|explicit risk/reject contract|
|S26|leave one group out conformal prediction source shift regression paper|[A Trust Score for Classification](https://proceedings.neurips.cc/paper/2018/hash/7180cffd6a8e829dacfc2a31b3f72ece-Abstract.html)|USE|nearest analog support|
|S27|distribution free prediction sets covariate shift NeurIPS paper|[Energy-based Out-of-distribution Detection](https://proceedings.neurips.cc/paper/2020/hash/f5496252609c43eb8a3d147ab9b9c006-Abstract.html)|USE|deferred OOD extension|
|S28|source conditional conformal prediction domain generalization regression|[Uncertainty Prediction for Machine Learning Models of Material Properties](https://pubs.acs.org/doi/10.1021/acsomega.1c03752)|USE|materials PI calibration/sharpness|
|S29|selective regression reject option uncertainty prediction interval primary paper|[Reliable and explainable machine-learning methods for accelerated material discovery](https://www.nature.com/articles/s41524-019-0248-2)|USE|materials trust/imbalance|
|S30|selective prediction risk coverage curve regression paper PMLR|[Realistic material property prediction using domain adaptation based machine learning](https://doi.org/10.1039/D3DD00162H)|USE|random-vs-OOD split honesty|
|S31|trust score model confidence nearest neighbor paper NeurIPS|[Model Cards for Model Reporting](https://dl.acm.org/doi/10.1145/3287560.3287596)|USE|user-visible limitations|
|S32|conformal risk control abstention regression primary paper|[NIST AI Risk Management Framework 1.0](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf)|USE|traceability and risk communication|
|S33|robust Mahalanobis distance outlier detection minimum covariance determinant paper|[Strictly Proper Scoring Rules, Prediction, and Estimation](https://doi.org/10.1198/016214506000001437)|USE|interval scoring|
|S34|k nearest neighbor out of distribution detection primary paper 2022|[Wilson confidence limits](https://doi.org/10.1080/01621459.1927.10502953)|USE|coverage diagnostic|
|S35|energy based out of distribution detection NeurIPS 2020 paper|[Distribution-Free Predictive Inference for Regression](https://arxiv.org/abs/1604.04173)|USE|finite_sample_quantile + leakage boundary|
|S36|deep nearest neighbors out of distribution detection regression tabular paper|[Conformalized Quantile Regression](https://proceedings.neurips.cc/paper/2019/hash/5103c3584b063c431bd1268e9b5e76fb-Abstract.html)|USE|heteroscedastic interval option|
|S37|localized conformal prediction regression nearest neighbors paper|[A Tutorial on Conformal Prediction](https://jmlr.org/papers/v9/shafer08a.html)|USE|exchangeability boundary|
|S38|locally adaptive conformal regression heteroscedastic paper|[Split Conformal Prediction and Non-Exchangeable Data](https://jmlr.org/papers/v25/23-1553.html)|USE|source-shift downgrade|
|S39|conformalized quantile regression heteroscedastic finite sample paper|[Conformal Prediction Under Covariate Shift](https://arxiv.org/abs/1904.06019)|USE|covariate-shift boundary|
|S40|jackknife plus regression prediction intervals Annals Statistics paper|[Adaptive Conformal Inference Under Distribution Shift](https://arxiv.org/abs/2106.00170)|USE|static qhat limitation|
|S41|uncertainty quantification materials informatics prediction intervals alloy property primary paper|[Jackknife+ Prediction Intervals for Regression](https://arxiv.org/abs/1905.02928)|USE|explicit method identity|
|S42|applicability domain materials informatics alloy machine learning extrapolation paper|[Conformal Risk Control](https://arxiv.org/abs/2208.02814)|USE|explicit risk/reject contract|
|S43|titanium alloy machine learning uncertainty quantification prediction interval paper|[A Trust Score for Classification](https://proceedings.neurips.cc/paper/2018/hash/7180cffd6a8e829dacfc2a31b3f72ece-Abstract.html)|USE|nearest analog support|
|S44|materials property prediction out of distribution detection domain shift paper|[Energy-based Out-of-distribution Detection](https://proceedings.neurips.cc/paper/2020/hash/f5496252609c43eb8a3d147ab9b9c006-Abstract.html)|USE|deferred OOD extension|
|S45|model cards model reporting uncertainty limitations primary paper|[Uncertainty Prediction for Machine Learning Models of Material Properties](https://pubs.acs.org/doi/10.1021/acsomega.1c03752)|USE|materials PI calibration/sharpness|
|S46|NIST AI risk management uncertainty communication model outputs official|[Reliable and explainable machine-learning methods for accelerated material discovery](https://www.nature.com/articles/s41524-019-0248-2)|USE|materials trust/imbalance|
|S47|evidence cards machine learning prediction uncertainty user interface research paper|[Realistic material property prediction using domain adaptation based machine learning](https://doi.org/10.1039/D3DD00162H)|USE|random-vs-OOD split honesty|
|S48|human centered uncertainty visualization prediction intervals decision support paper|[Model Cards for Model Reporting](https://dl.acm.org/doi/10.1145/3287560.3287596)|USE|user-visible limitations|
|S49|prediction interval coverage probability mean width calibration error regression primary source|[NIST AI Risk Management Framework 1.0](https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf)|USE_AS_DIAGNOSTIC|traceability and risk communication|
|S50|Wilson score interval binomial coverage diagnostic paper official|[Strictly Proper Scoring Rules, Prediction, and Estimation](https://doi.org/10.1198/016214506000001437)|USE_AS_DIAGNOSTIC|interval scoring|
|S51|conformal prediction calibration curve regression coverage diagnostics paper|[Wilson confidence limits](https://doi.org/10.1080/01621459.1927.10502953)|USE_AS_DIAGNOSTIC|coverage diagnostic|
|S52|prediction interval scoring rule Winkler score primary source|[Distribution-Free Predictive Inference for Regression](https://arxiv.org/abs/1604.04173)|USE_AS_DIAGNOSTIC|finite_sample_quantile + leakage boundary|
