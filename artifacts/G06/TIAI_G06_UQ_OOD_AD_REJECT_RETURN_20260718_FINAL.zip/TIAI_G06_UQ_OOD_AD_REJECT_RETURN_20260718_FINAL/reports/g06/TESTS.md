# Tests

Covers finite-sample quantile, Mondrian fallback, held-out-source leakage,
coverage diagnostics, exact uncertainty adapter, all four fail-closed layers,
GE5/HQ-LOSO honesty, TMC reinforcement fields, tail-trust, negative bounds,
YS>UTS, and reject-card construction.
