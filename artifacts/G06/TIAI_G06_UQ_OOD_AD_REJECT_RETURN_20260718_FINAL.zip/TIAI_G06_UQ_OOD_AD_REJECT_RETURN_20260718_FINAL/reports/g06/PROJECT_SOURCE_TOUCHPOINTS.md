# Project Source Touchpoints

- Sole authority: `TIAI_WEB36_V24_AGENT_NATIVE_ONE_WAVE_FULL_20260717.zip`.
- Window prompt: `G06_UQ_OOD_AD_REJECT.md`; exact write scope locked.
- Current-turn literature mounts: B006–B010. B001–B005 are not claimed present.
- Read-only neighboring contracts: R01 conformal kernel and R14 tail-trust.
- SSOT at `sddvacav/tiai-agent-os@3008e56`:
  `claim_envelope.py`, `ClaimEnvelope.schema.json`, `property_discriminator.py`,
  `champion_serving.py`.
- Adapted exact uncertainty fields: method, nominal_coverage, interval,
  conformal_qhat, qhat_scope, ad_distance_mean10, ad_threshold_q95.
- Frozen AD rule retained: `ad_distance_mean10 <= ad_threshold_q95`.
- No Track-S, R01, R14, common schema, or campaign wiring mutation.
