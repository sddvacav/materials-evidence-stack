# Pressure Test

- missing UQ -> REJECT; no point-only fallback
- AD distance >= q95 -> REJECT
- GE5 presented as LOSO -> no upgrade
- TMC reinforcement descriptors missing -> REJECT
- unsupported extreme -> retained but REJECT
- YS > UTS -> REJECT
- held-out source in calibration -> LeakageError
