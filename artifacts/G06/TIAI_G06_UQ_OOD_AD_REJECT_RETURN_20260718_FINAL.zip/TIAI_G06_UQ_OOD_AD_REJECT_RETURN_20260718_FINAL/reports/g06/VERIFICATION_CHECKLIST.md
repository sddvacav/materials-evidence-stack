# Verification Checklist

- [x] exact G06 executable write scope
- [x] forced DATA files
- [x] conformal equation and runnable code
- [x] four-layer fail-closed gate
- [x] firewall/tail-trust machine labels
- [x] Chinese UI/API specification
- [x] GE5/HQ-LOSO separation
- [x] 52 English search records
- [x] compile + unittest + smoke + patch apply-check
- [ ] empirical HQ-LOSO receipt (promotion blocker only)
