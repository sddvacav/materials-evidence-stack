# Blockers

Code/apply blockers: none after included checks.

Scientific promotion blockers:
1. HQ-LOSO split/calibration/evaluation receipts absent. Close by replaying every
   target/route with held-out source excluded from all fitting and recording PICP,
   width, interval score, AD coverage, nearest analog coverage, and subject SHA.
2. This policy window creates zero empirical HQ rows/fulltext extractions; bind to
   the existing HQ corpus instead of creating a second corpus.
3. Current-turn literature mounts include B006–B010 only; mount B001–B005 only if
   a later extraction requires them.
