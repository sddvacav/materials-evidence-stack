# Claim Boundary

Can claim: executable deterministic G06 gate; exact ClaimEnvelope adapter;
finite-sample conformal/Mondrian/leakage/coverage code; schemas/fixtures/tests.

Cannot claim: empirical Ti/TMC coverage/R²/MAE/OOD AUROC; HQ-LOSO closure;
production champion/publication default/platform FULLSCORE; optimality of default
thresholds; B001–B005 current-turn presence; model training or Track-S mutation.

GE5 is not LOSO. Missing evidence downgrades/rejects, never infers a pass.
