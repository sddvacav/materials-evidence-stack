from __future__ import annotations
import copy, json, unittest
from pathlib import Path
from modules.w08_mq_uq_conformal_calibration.g06_reject_guard import (
    CalibrationRecord, GroupKey, LeakageError, MondrianCalibrator,
    adapt_claim_uncertainty, build_reject_card, coverage_audit,
    evaluate_request, finite_sample_quantile, load_policy,
)

ROOT = Path(__file__).resolve().parents[2]
POLICY = load_policy(ROOT / "DATA/g06/calibration_policy.yaml")
BASE = json.loads((ROOT / "DATA/g06/smoke_request.json").read_text(encoding="utf-8"))

def p(**changes):
    value = copy.deepcopy(BASE)
    for dotted, replacement in changes.items():
        parts = dotted.split("__")
        cursor = value
        for part in parts[:-1]: cursor = cursor[part]
        cursor[parts[-1]] = replacement
    return value

class MathTests(unittest.TestCase):
    def test_quantile(self): self.assertEqual(finite_sample_quantile(range(1,10), .1), 9)
    def test_leakage(self):
        records=[CalibrationRecord(10,9,GroupKey("uts_mpa","near_alpha","DED","RT"),"study-x")]
        with self.assertRaises(LeakageError): MondrianCalibrator(POLICY).fit(records,{"study-x"})
    def test_fallback(self):
        records=[CalibrationRecord(1000+i,995+i,GroupKey("uts_mpa","near_alpha","DED","RT" if i<10 else "HT"),f"s{i}") for i in range(40)]
        out=MondrianCalibrator(POLICY).fit(records).interval(1200,1,GroupKey("uts_mpa","near_alpha","DED","RT"),0)
        self.assertTrue(out["ok"]); self.assertEqual(out["qhat_scope"],"target_family_route"); self.assertEqual(out["calibration_n"],40)
    def test_coverage(self):
        out=coverage_audit([1,2,3],[[0,2],[1,3],[0,2]],.1)
        self.assertEqual(out["covered_n"],2)

class GateTests(unittest.TestCase):
    def d(self, **changes): return evaluate_request(p(**changes), POLICY)
    def test_green(self):
        out=self.d(); self.assertEqual(out.decision.value,"ACCEPT"); self.assertTrue(out.machine_labels["fullscore_eligible_for_this_row"]); self.assertFalse(out.machine_labels["platform_fullscore_claimed"])
    def test_ge5_only(self):
        out=self.d(claim_evidence__hq_loso_receipt_ref="",claim_evidence__caliber="COND_GROUP_GE5")
        self.assertEqual(out.decision.value,"WARN"); self.assertFalse(out.machine_labels["fullscore_eligible_for_this_row"])
    def test_firewall(self): self.assertEqual(self.d(input_integrity__firewall_status="REJECT").decision.value,"REJECT")
    def test_ad_outside(self):
        out=self.d(uncertainty__ad_distance_mean10=.80); self.assertEqual(out.decision.value,"REJECT"); self.assertEqual(out.machine_labels["ad_state"],"OUTSIDE")
    def test_ad_borderline(self): self.assertEqual(self.d(uncertainty__ad_distance_mean10=.65).decision.value,"WARN")
    def test_missing_uq(self):
        value=p(); value.pop("uncertainty"); out=evaluate_request(value,POLICY)
        self.assertEqual(out.decision.value,"REJECT"); self.assertIn("UNCERTAINTY_CONTRACT_INVALID",out.machine_labels["triggered_codes"])
    def test_calibration_n(self): self.assertEqual(self.d(claim_evidence__calibration_n=8).decision.value,"REJECT")
    def test_tail_candidate(self): self.assertEqual(self.d(tail_trust__state="TAIL_CANDIDATE").decision.value,"WARN")
    def test_unsupported_extreme(self): self.assertEqual(self.d(tail_trust__state="UNSUPPORTED_EXTREME").decision.value,"REJECT")
    def test_ys_gt_uts(self):
        value=p(target="ys_mpa",point=1600.0); value["companion_uts_mpa"]=1500.0
        out=evaluate_request(value,POLICY); self.assertIn("YS_EXCEEDS_UTS",out.machine_labels["triggered_codes"])
    def test_negative_bound(self): self.assertEqual(self.d(uncertainty__interval=[-5,50],point=20).decision.value,"REJECT")
    def test_tmc_fields(self): self.assertEqual(self.d(input_integrity__reinforcement_fields_complete=False).decision.value,"REJECT")
    def test_adapter_exact(self):
        self.assertEqual(set(adapt_claim_uncertainty(BASE["uncertainty"])),{"method","nominal_coverage","interval","conformal_qhat","qhat_scope","ad_distance_mean10","ad_threshold_q95"})
    def test_card(self):
        card=build_reject_card(self.d(claim_evidence__hq_loso_receipt_ref="",claim_evidence__caliber="COND_GROUP_GE5"),"c","t")
        self.assertIn("dual_caliber",card); self.assertIn("machine_labels",card)

if __name__ == "__main__": unittest.main()
