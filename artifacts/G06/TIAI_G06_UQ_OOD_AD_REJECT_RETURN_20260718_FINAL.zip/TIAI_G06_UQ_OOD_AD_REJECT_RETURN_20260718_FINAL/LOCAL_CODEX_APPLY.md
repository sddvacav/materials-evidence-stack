# LOCAL CODEX APPLY — 0.01%

```powershell
cd E:\Generated\tiai-agent-os
git status --short
git rev-parse HEAD
# expected: 3008e561f618376031cd229979c7fc3dda722f0e
$RET = "<UNZIPPED_FINAL_RETURN>"
git apply --check "$RET\PATCHES\G06_UQ_OOD_AD_REJECT.patch"
git apply "$RET\PATCHES\G06_UQ_OOD_AD_REJECT.patch"
$env:PYTHONPATH = "."
python -m compileall -q modules\w08_mq_uq_conformal_calibration\g06_reject_guard
python -m unittest discover -s tests\g06 -v
python -m modules.w08_mq_uq_conformal_calibration.g06_reject_guard.cli --policy DATA\g06\calibration_policy.yaml --input DATA\g06\smoke_request.json
git diff --check
```
Do not retrain/promote/overwrite Track-S during apply.
