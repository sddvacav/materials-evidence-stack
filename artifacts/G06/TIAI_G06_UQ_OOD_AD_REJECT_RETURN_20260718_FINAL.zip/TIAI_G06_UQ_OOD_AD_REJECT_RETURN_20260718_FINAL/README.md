# TiAI G06 FINAL Return

UQ · OOD · AD · reject recommendation for titanium alloys/TMCs. Additive return
against `3008e56`. Includes modules, tests, forced DATA, METHOD_IR, source ledger,
Chinese UI/API contract, patch, manifests, and evidence. Claim ceiling is
`below_gate_continue_optimization`; no empirical HQ-LOSO/FULLSCORE claim.
