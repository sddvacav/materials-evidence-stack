# QM14 rebuilt executive verdict

`WINDOW=QM14 | SNAPSHOT=QM14_REBUILT_DERIVED_58ee2e62a9384c42 | INPUT_MODE=QUANT_EXECUTE/COHORT_BUILD`

## Supersession decision

The earlier `/mnt/data/FINAL_QM14.zip` is invalidated and must not be absorbed. It omitted the 2025 TiC/Ti-5556 thesis, underused the 7715D primary paper/thesis evidence, and asserted that quantitative support stopped at 700 °C. Direct same-paper TiAl/Y2O3 evidence exists at 800 °C. This rebuild corrects the cohort and preserves the narrower claim ceiling: **800 °C TiAl-specific evidence is not generic 800 °C titanium-service qualification**.

## Quantitative answer

1. **Steady creep rate:** 26 exact same-paper condition effects were recovered from 4 independent papers. All exact contrasts are negative (`all_negative=True`), but the condition-specific change spans **-61.1% to -2.3%**. The spread is not noise to be averaged away: it tracks matrix family, reinforcement system, heat treatment, temperature and stress.
2. **Processing interaction:** in LPBF Ti-6Al-4V, TiB changed rate/life from -24.5% / -14.7% in the as-built state to -61.1% / 866.7% after supertransus treatment. Lower rate therefore does **not** guarantee longer life.
3. **Stress exponent:** reinforcement does not impose one directional shift. Wang's threshold-corrected matrix/TMC data share true `n=3.5`; Xu reports `2.92→3.32`; Frontiers reports higher apparent n in the TMC; Guo reports `4.03→3.09` at 800 °C. A universal n would mix different stress definitions and mechanisms.
4. **Activation energy:** Wang's threshold correction collapses matrix and TMC to `Q=343 kJ/mol`; Ye's Q changes strongly with initial phase state and dose; Frontiers' matrix and TMC Q were evaluated at different stresses. No universal reinforcement delta-Q is identifiable.
5. **Rupture life:** exact/derived paired evidence is sparse and interaction-dominated. At 800 °C/350 MPa, Y2O3-bearing TiAl increased life from a source-text-derived 15 h to 77 h (`lnRR=1.636`, 413.3%). This is a Level-2 same-paper estimate, not a design allowables claim.

## Claim ceiling

Maximum claim level is **2: same-paper, condition-specific paired association**. A pooled causal coefficient, universal n/Q, stress-temperature rupture contour, Larson–Miller parameter, Monkman–Grant law, Gold promotion, production-model registration and `VALIDATED` formulation are forbidden with the present support.

## Terminal state

The rebuilt analysis is complete for the recovered evidence, but authoritative closure is blocked by the absent V29/Q40 atomic snapshot, original byte-level source hashes, replicate variances, censoring metadata and exact tables for several identified studies.
