# Acceptance commands

```bash
python -m pip install -r requirements.lock
python plot_code/reproduce_all.py
python tests/test_outputs.py .
sha256sum -c CHECKSUMS.sha256
python - <<'PY'
import zipfile
z=zipfile.ZipFile('../FINAL_QM14_REBUILT.zip')
assert z.testzip() is None
assert not any(n.lower().endswith(('.zip','.7z','.rar')) for n in z.namelist())
print('ZIP_PASS')
PY
```
