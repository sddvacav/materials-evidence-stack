from _common import *
import re
root=get_root(); df=pd.read_csv(root/"figure_data/fig03_q_forest.csv")
rows=[]
for _,r in df.iterrows():
    txt=str(r["value"]); nums=[float(x) for x in re.findall(r"[0-9]+(?:\.[0-9]+)?",txt)]
    if not nums: continue
    lo=min(nums); hi=max(nums); mid=(lo+hi)/2
    rows.append((r,lo,hi,mid))
rows=sorted(rows,key=lambda z:z[3]); fig,ax=plt.subplots(figsize=(10,max(6,.36*len(rows))))
for i,(r,lo,hi,mid) in enumerate(rows):
    ax.errorbar(mid,i,xerr=[[mid-lo],[hi-mid]],fmt="o")
labels=[f"{r['paper_uid']} | {r['sample_uid']} | {r['basis']}" for r,_,_,_ in rows]
ax.set_yticks(range(len(rows)),labels,fontsize=6); ax.set_xlabel("Activation energy, Q (kJ mol$^{-1}$)")
ax.set_title("Activation-energy evidence forest"); ax.grid(True,axis="x",alpha=.25)
fig.text(.01,.01,"Ranges are source-reported. Different stress definitions and mechanism regimes are not pooled.",fontsize=8)
save3(fig,root,"fig03_q_forest")
