from _common import *
import numpy as np
root=get_root(); df=pd.read_csv(root/"figure_data/fig04_rupture_support.csv")
fig,ax=plt.subplots(figsize=(9,6))
for _,r in df.iterrows():
    life=float(r["rupture_life_h"]); ax.scatter(float(r["stress_MPa"]),float(r["temperature_C"]),s=30+45*np.log10(1+life))
    ax.annotate(f"{r['paper_uid']}\n{r['sample_uid']}: {life:g} h",(float(r["stress_MPa"]),float(r["temperature_C"])),xytext=(4,4),textcoords="offset points",fontsize=7)
ax.set_xlabel("Applied stress (MPa)"); ax.set_ylabel("Temperature (°C)"); ax.set_title("Rupture-life support map — no interpolation")
ax.grid(True,alpha=.25); fig.text(.01,.01,"Only observed/explicitly derived rupture points. A contour surface, LMP and Monkman–Grant law are NOT_IDENTIFIABLE.",fontsize=8)
save3(fig,root,"fig04_rupture_support_no_interpolation")
