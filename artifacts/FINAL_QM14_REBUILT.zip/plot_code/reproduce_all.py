from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1]
for i in range(1,7):
    subprocess.run([sys.executable,str(root/"plot_code"/f"plot_fig{i:02d}.py"),"--root",str(root)],check=True)
print("plots_generated=6 formats=SVG/PDF/PNG")
