from pathlib import Path
import argparse
import matplotlib.pyplot as plt
import pandas as pd

def get_root():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=str(Path(__file__).resolve().parents[1]))
    return Path(ap.parse_args().root).resolve()

def save3(fig, root, stem):
    out=root/"figures"
    out.mkdir(parents=True,exist_ok=True)
    fig.savefig(out/(stem+".svg"),bbox_inches="tight")
    fig.savefig(out/(stem+".pdf"),bbox_inches="tight")
    fig.savefig(out/(stem+".png"),dpi=600,bbox_inches="tight")
    plt.close(fig)
