from _common import *
import re
root=get_root(); df=pd.read_csv(root/"figure_data/fig05_mechanism_regimes.csv")
fig,ax=plt.subplots(figsize=(10,7))
for i,r in df.iterrows():
    t=str(r["temperature_C"]); s=str(r["stress_MPa"]); tn=[float(x) for x in re.findall(r"[0-9]+(?:\.[0-9]+)?",t)]; sn=[float(x) for x in re.findall(r"[0-9]+(?:\.[0-9]+)?",s)]
    if not tn or not sn: continue
    x=sum(sn)/len(sn); y=sum(tn)/len(tn); ax.scatter(x,y,s=70); ax.annotate(f"{r['paper_uid']}\n{r['mechanism']}",(x,y),xytext=(5,5),textcoords="offset points",fontsize=6,wrap=True)
ax.set_xlabel("Stress support midpoint (MPa)"); ax.set_ylabel("Temperature support midpoint (°C)"); ax.set_title("Mechanism-regime support map")
ax.grid(True,alpha=.25); fig.text(.01,.01,"Points mark evidence islands, not fitted regime boundaries. Cross-island universal n/Q is physically invalid.",fontsize=8)
save3(fig,root,"fig05_mechanism_regime_map")
