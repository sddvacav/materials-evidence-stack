from _common import *
root=get_root(); df=pd.read_csv(root/"figure_data/fig06_creep_effect_forest.csv").sort_values("lnRR")
df["label"]=df["paper_uid"]+" | "+df["sample_uid_treatment"]+" | "+df["temperature_C"].astype(str)+" C/"+df["stress_MPa"].astype(str)+" MPa"
fig,ax=plt.subplots(figsize=(10,max(7,.26*len(df))))
y=range(len(df)); ax.scatter(df["lnRR"],list(y)); ax.axvline(0,linewidth=1)
ax.set_yticks(list(y),df["label"],fontsize=6); ax.set_xlabel("ln response ratio, ln(rate$_{TMC}$/rate$_{control}$)")
ax.set_title("Condition-specific creep-rate effects"); ax.grid(True,axis="x",alpha=.25)
fig.text(.01,.01,f"Exact same-paper effects; independent papers={df.paper_uid.nunique()}, pairs={len(df)}. Negative values indicate lower rate.",fontsize=8)
save3(fig,root,"fig06_creep_effect_forest")
