from _common import *
root=get_root(); df=pd.read_csv(root/"figure_data/fig02_n_forest.csv")
df=df[pd.to_numeric(df["value"],errors="coerce").notna()].copy(); df["v"]=pd.to_numeric(df["value"])
df["label"]=df["paper_uid"]+" | "+df["sample_uid"]+" | "+df["temperature_C"].astype(str)+" C | "+df["basis"]
df=df.sort_values("v"); fig,ax=plt.subplots(figsize=(10,max(6,.28*len(df))))
y=range(len(df)); ax.scatter(df["v"],list(y)); ax.set_yticks(list(y),df["label"],fontsize=6)
ax.axvline(3.5,linewidth=1,linestyle="--"); ax.axvline(5,linewidth=1,linestyle=":")
ax.set_xlabel("Stress exponent, n"); ax.set_title("Reported and recomputed stress exponents")
ax.grid(True,axis="x",alpha=.25); fig.text(.01,.01,"No pooled n: apparent, true threshold-corrected, and recomputed values are distinct estimands.",fontsize=8)
save3(fig,root,"fig02_n_forest")
