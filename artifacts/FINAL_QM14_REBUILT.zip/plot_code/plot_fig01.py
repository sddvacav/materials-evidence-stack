from _common import *
import numpy as np
root=get_root(); df=pd.read_csv(root/"figure_data/fig01_creep_rate_stress.csv")
fig,ax=plt.subplots(figsize=(10,7))
for key,g in df.groupby(["paper_uid","sample_uid","temperature_C","heat_treatment"]):
    if g["stress_MPa"].nunique()<2: continue
    g=g.sort_values("stress_MPa")
    label=f"{key[0]} | {key[1]} | {key[2]:g} C"
    ax.plot(g["stress_MPa"],g["steady_creep_rate_s-1"],marker="o",label=label)
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("Applied stress (MPa)"); ax.set_ylabel("Steady-state creep rate (s$^{-1}$)")
ax.set_title("Creep rate–stress support by study and condition")
ax.grid(True,which="both",alpha=.25); ax.legend(fontsize=6,ncol=2)
fig.text(.01,.01,"Exact table rows; no cross-mechanism averaging. Independent papers=3; support=500–700 °C, 100–400 MPa.",fontsize=8)
save3(fig,root,"fig01_creep_rate_stress_loglog")
