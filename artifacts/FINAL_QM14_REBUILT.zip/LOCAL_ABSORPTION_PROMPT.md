# Local absorption prompt

Reject the superseded `FINAL_QM14.zip`. Verify `FINAL_QM14_REBUILT.zip` with `CHECKSUMS.sha256`, ZIP CRC/testzip, schema/UID uniqueness and independent recalculation of every lnRR. Map derived paper/sample/condition IDs onto the authoritative V29/Q40 registry without overwriting conflicts. Attach original PDF/XML byte hashes and member provenance. Keep all current results at Claim Level 2 and do not promote to Gold, production models or VALIDATED formulations. Re-run after satisfying `WEB_TO_LOCAL_REQUEST.json`; only then consider authoritative snapshot promotion.
