# Supersession notice

- Superseded artifact: `FINAL_QM14.zip`
- Previously reported SHA-256: `35bcb0c2bbdbafde0dea1bf16afb89a3dac3b4ba49b5e729547dd764486a8d56`
- Disposition: **INVALID FOR ABSORPTION**
- Causes: omitted primary evidence; false upper-temperature support statement; incomplete provenance/hash claims.
- Replacement: `FINAL_QM14_REBUILT.zip`
- The replacement does not self-promote to Gold or production status.
