#!/usr/bin/env python3
import csv,hashlib,json,math,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required=['00_EXECUTIVE_VERDICT.md','INPUT_LEDGER.csv','ANALYSIS_COHORT.csv','PAIR_MATCHES.csv','EFFECT_ESTIMATES.csv','HIERARCHICAL_RESULTS.csv','DOSE_RESPONSE.csv','INTERACTION_EFFECTS.csv','HETEROGENEITY.csv','SENSITIVITY_ANALYSIS.csv','NULL_NEGATIVE_RESULTS.csv','CONFLICT_LEDGER.csv','PROVENANCE.jsonl','METHODS.md','LIMITATIONS.md','PLOT_SPECS.json','WEB_TO_LOCAL_REQUEST.json','LOCAL_ABSORPTION_PROMPT.md','WINDOW_STATUS.json','MANIFEST.json','CHECKSUMS.sha256','CREEP_CURVE_LEDGER.csv','CREEP_PARAMETERS.csv','RUPTURE_EFFECTS.csv','CREEP_MECHANISM_REGIMES.csv','SUPERSESSION_NOTICE.md']
checks=[]
def ok(name,cond):
    checks.append((name,bool(cond))); assert cond,name
ok('required_files',all((root/x).exists() for x in required))
def readcsv(n):
    with (root/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
curves=readcsv('CREEP_CURVE_LEDGER.csv'); pairs=readcsv('PAIR_MATCHES.csv'); eff=readcsv('EFFECT_ESTIMATES.csv')
ok('atomic_uid_unique',len({r['record_uid'] for r in curves})==len(curves))
ok('pair_uid_unique',len({r['pair_uid'] for r in pairs})==len(pairs))
ok('effect_uid_unique',len({r['effect_uid'] for r in eff})==len(eff))
ok('effect_math',all(abs(float(r['lnRR'])-math.log(float(r['treatment_value'])/float(r['control_value'])))<1e-12 for r in eff))
creep=[r for r in eff if r['outcome']=='steady_creep_rate_s-1']
ok('creep_effects_condition_specific',len(creep)>=25 and all(float(r['lnRR'])<0 for r in creep))
status=json.loads((root/'WINDOW_STATUS.json').read_text())
ok('status_legal',status['status']=='CONTINUE_DATA_GAP' and status['claim_level_max']==2)
for i in range(1,7):
    stem=json.loads((root/'PLOT_SPECS.json').read_text())[i-1]['stem']
    for ext in ['svg','pdf','png']:
        p=root/'figures'/f'{stem}.{ext}'; ok(f'plot_{i}_{ext}',p.exists() and p.stat().st_size>1000)
for line in (root/'CHECKSUMS.sha256').read_text().splitlines():
    h,name=line.split('  ',1); p=root/name; ok('sha_'+name,hashlib.sha256(p.read_bytes()).hexdigest()==h)
ok('no_nested_archive',not any(p.suffix.lower() in {'.zip','.7z','.rar'} for p in root.rglob('*') if p.is_file()))
print(json.dumps({'pass':True,'checks':len(checks)},indent=2))
