# Limitations

1. The authoritative V29/Q40 atomic snapshot and byte-level source hashes were not available in the web-return runtime; this package uses a derived snapshot and identifier hashes only.
2. Most source tables do not report replicate-level uncertainty, preventing valid pair-level confidence intervals and a defensible random-effects meta-analysis.
3. Several studies are figure/abstract-indexed but lack authoritative exact creep tables in the current input surface; they are not digitized or guessed.
4. Rupture evidence is too sparse for Larson–Miller, Monkman–Grant or a stress–temperature contour.
5. Matrix families span alpha/beta Ti, near-alpha Ti, Ti-6Al-4V and TiAl. Their mechanisms and homologous temperatures differ; pooled n/Q has no physical meaning.
6. The Guo matrix rupture life is derived from a reported 62 h life extension relative to the 77 h TMC value and is isolated in sensitivity analysis.
7. Ye's reinforcement dose is precursor wt.% rather than verified TiC vol.%; dose efficiency is therefore precursor-specific.
