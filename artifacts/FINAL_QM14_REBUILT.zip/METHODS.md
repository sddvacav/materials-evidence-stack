# Methods

## Estimands

For a same-paper matched control/treatment pair and positive outcome `Y`:

- absolute effect: `Y_TMC - Y_control`
- log response ratio: `lnRR = ln(Y_TMC/Y_control)`
- percent change: `100*(exp(lnRR)-1)`

Creep rate uses negative lnRR as beneficial; rupture life uses positive lnRR as beneficial. No effect is averaged across temperature, stress, matrix state or test mode before the condition-specific estimate is retained.

## Atomicity and matching

Atomic row = paper × sample × actual/declared reinforcement × process × heat treatment × microstructure × test mode × temperature × stress × outcome. All numerical effects in `EFFECT_ESTIMATES.csv` are grade-A same-paper matches. Figure/abstract-only studies remain cohort or mechanism support and are not silently converted into numeric rows.

## Parameter fitting

Recomputed stress exponent is the OLS slope of `ln(creep rate)` against `ln(stress)` only within one paper/sample/temperature/heat-treatment block with at least three stress points. Reported apparent, true threshold-corrected and recomputed n are stored as different `basis` values. Reported Q values are never pooled when constant-stress definitions differ.

## Uncertainty

The source tables generally lack replicate variance. Pair-level confidence intervals are therefore marked `NOT_ESTIMABLE`, not fabricated. A deterministic, equal-paper-weight paper-cluster bootstrap (`seed=20260713`, 10,000 resamples) summarizes observed heterogeneity; it is explicitly descriptive. LOPO and leave-family-out analyses stress-test sign dependence.

## Composition and dose

Ye's dose response is defined on Cr3C2 precursor wt.%, because actual TiC volume fraction is not reported. This cannot be interpreted as TiC efficiency per vol.%. Two-point dose series are marked non-identifiable for curvature.

## Rupture surface

The support contains disconnected points rather than a connected temperature–stress grid. The delivered rupture figure is a no-interpolation support map. Larson–Miller and Monkman–Grant fits are not performed.

## Software

Python 3.11; numpy/pandas/matplotlib exact pins in `requirements.lock`. Plot outputs are generated from delivered CSV files by delivered scripts. No LLM is required for recomputation.
