#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent; sys.path.insert(0,str(ROOT/"src"))
from ssl04.guard import enforce
def main():
    p=argparse.ArgumentParser(); p.add_argument("--authority",default="authority"); p.add_argument("--smoke",action="store_true"); a=p.parse_args()
    try: enforce(ROOT/a.authority)
    except FileNotFoundError as e: print(json.dumps({"status":"BLOCKED_INPUT","error":str(e)})); return 42
    print(json.dumps({"status":"INPUT_GATE_PASS","next":"fold-local training"})); return 0
if __name__=="__main__": raise SystemExit(main())
