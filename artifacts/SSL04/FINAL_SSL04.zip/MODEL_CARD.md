# Model Card

Status `NOT_TRAINED`; registration forbidden. Intended comparison: scratch, Ti-only, TMC-only, Ti+TMC, approved cross-domain, DANN and MMD under identical folds, seeds, heads and budgets. No checkpoint exists.
