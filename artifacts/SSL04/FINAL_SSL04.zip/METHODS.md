# Methods

Bind immutable MC01/MC02 hashes; fit preprocessing and SSL inside each outer-training fold; purge paper/sample/batch/derivation/near-duplicate links to outer test; compare scratch and all transfer routes using five seeds; report standard K-fold plus leave-paper/source-out, leave-family-out and time-out; retain failed folds and negative transfer; separate inductive and transductive results.
