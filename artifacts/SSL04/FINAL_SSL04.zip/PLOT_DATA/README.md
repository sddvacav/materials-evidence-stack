No plot data: no training.
