from pathlib import Path
import sys,unittest
R=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(R/"src"))
from ssl04.leakage import purge
class T(unittest.TestCase):
 def test_overlap(self):
  keep,rem=purge([{"record_uid":"a","paper_uid":"P1","sample_uid":"S1"},{"record_uid":"b","paper_uid":"P2","sample_uid":"S2"}],[{"paper_uid":"P1","sample_uid":"S1"}]); self.assertEqual("b",keep[0]["record_uid"]); self.assertEqual("IDENTITY_GROUP_OVERLAP",rem[0]["reason"])
