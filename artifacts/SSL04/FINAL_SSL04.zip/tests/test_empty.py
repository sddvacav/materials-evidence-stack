from pathlib import Path
import csv,json,unittest
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_no_metrics(self): self.assertEqual(1,len(list(csv.reader((R/"METRICS_BY_FOLD.csv").open()))))
 def test_no_training_complete(self): self.assertNotIn("TRAINING_COMPLETE",{json.loads(x)["event"] for x in (R/"TRAINING_LOG.jsonl").read_text().splitlines() if x})
