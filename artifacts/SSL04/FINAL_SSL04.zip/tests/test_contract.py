from pathlib import Path
import csv,json,unittest
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_required(self):
  req=["00_EXECUTIVE_VERDICT.md","SOURCE_UTILIZATION_MATRIX.csv","PRIMARY_LITERATURE_AUDIT.csv","INPUT_LEDGER.csv","DATASET_CARD.md","RUN_CONFIG.yaml","ENVIRONMENT_LOCK.txt","TRAINING_LOG.jsonl","OOF_PREDICTIONS.parquet","METRICS_BY_FOLD.csv","METRICS_BY_SEED.csv","ERROR_ANALYSIS.csv","MODEL_CARD.md","METHODS.md","LIMITATIONS.md","NEGATIVE_RESULTS.md","OPEN_ISSUES.md","WEB_TO_LOCAL_REQUEST.json","LOCAL_ABSORPTION_PROMPT.md","WINDOW_STATUS.json","DOMAIN_TAXONOMY.csv","PRETRAIN_CORPUS_LEDGER.csv","CROSS_DOMAIN_RESULTS.csv","DOMAIN_OVERLAP.csv","NEGATIVE_TRANSFER.csv","MANIFEST.json","CHECKSUMS.sha256"]
  self.assertEqual([], [x for x in req if not (R/x).is_file()])
 def test_status(self): self.assertEqual("BLOCKED_INPUT",json.loads((R/"WINDOW_STATUS.json").read_text())["status"])
 def test_no_pending(self):
  rows=list(csv.DictReader((R/"SOURCE_UTILIZATION_MATRIX.csv").open(encoding="utf-8"))); self.assertTrue(rows); self.assertNotIn("PENDING",{x["terminal_use_status"] for x in rows})
