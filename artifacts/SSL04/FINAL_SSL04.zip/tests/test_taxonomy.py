from pathlib import Path
import sys,unittest
R=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(R/"src"))
from ssl04.taxonomy import *
class T(unittest.TestCase):
 def test_nonti_target_block(self): self.assertFalse(target_allowed("nonti_external"))
 def test_tib(self): self.assertEqual("tmc_tib",infer({"matrix":"Ti-6Al-4V","reinforcement":"TiB whisker"}))
 def test_external_approval(self): self.assertFalse(pretrain_allowed("nonti_external")); self.assertTrue(pretrain_allowed("nonti_external",True))
