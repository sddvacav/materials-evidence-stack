from pathlib import Path
import hashlib,unittest
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_hashes(self):
  for line in (R/"CHECKSUMS.sha256").read_text().splitlines():
   exp,rel=line.split("  ",1); self.assertEqual(exp,hashlib.sha256((R/rel).read_bytes()).hexdigest(),rel)
