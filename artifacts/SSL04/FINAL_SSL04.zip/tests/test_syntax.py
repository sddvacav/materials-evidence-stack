from pathlib import Path
import py_compile,unittest
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def test_compile(self):
  for p in list((R/"src").rglob("*.py"))+[R/"run_all.py",R/"resume.py",R/"infer.py"]: py_compile.compile(str(p),doraise=True)
