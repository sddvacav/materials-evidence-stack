# Open Issues

- INPUT-001: snapshot/split absent.
- INPUT-002: Gold and screened-unlabeled parquet absent.
- INPUT-003: feature/target/seed/budget registries and leakage firewall absent.
- COMPUTE-001: local execution returned ClientError before file access.
- LICENSE-001: no non-Ti external corpus approved.
