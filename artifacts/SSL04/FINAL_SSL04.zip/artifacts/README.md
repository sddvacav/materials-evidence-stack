No model checkpoint exists.
