def build(input_dim,targets,latent=64):
    import torch,torch.nn as nn
    class GR(torch.autograd.Function):
        @staticmethod
        def forward(ctx,x,a): ctx.a=a; return x.view_as(x)
        @staticmethod
        def backward(ctx,g): return -ctx.a*g,None
    class M(nn.Module):
        def __init__(self):
            super().__init__(); self.encoder=nn.Sequential(nn.Linear(input_dim,256),nn.LayerNorm(256),nn.GELU(),nn.Linear(256,128),nn.GELU(),nn.Linear(128,latent)); self.decoder=nn.Linear(latent,input_dim); self.heads=nn.ModuleDict({t:nn.Linear(latent,1) for t in targets}); self.domain=nn.Linear(latent,2)
        def forward(self,x,alpha=0.):
            z=self.encoder(x); return {"z":z,"reconstruction":self.decoder(z),"predictions":{k:v(z).squeeze(-1) for k,v in self.heads.items()},"domain_logits":self.domain(GR.apply(z,alpha) if alpha else z)}
    return M()
