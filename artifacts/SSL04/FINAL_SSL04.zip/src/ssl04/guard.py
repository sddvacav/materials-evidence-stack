from pathlib import Path
REQUIRED=("MODEL_INPUT_SNAPSHOT.json","DATASET_FINGERPRINT.json","GOLD_ROWS.parquet","SCREENED_UNLABELED_ROWS.parquet","FEATURE_DICTIONARY.json","TARGET_REGISTRY.json","SPLIT_MANIFEST.json","SEED_REGISTRY.json","BUDGET_REGISTRY.json","LEAKAGE_FIREWALL.md","CHECKSUMS.sha256")
def enforce(directory):
    d=Path(directory); missing=[x for x in REQUIRED if not (d/x).is_file()]
    if missing: raise FileNotFoundError("missing authority: "+", ".join(missing))
    return [d/x for x in REQUIRED]
