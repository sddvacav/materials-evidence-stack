TI={"cp_ti","alpha","near_alpha","alpha_beta","metastable_beta","beta","tial"}
TMC={"tmc_tib","tmc_tic","tmc_sic_fiber","hybrid_tmc","tmc_other"}
def target_allowed(domain): return domain in TI|TMC
def pretrain_allowed(domain,external_approved=False): return target_allowed(domain) or (domain=="nonti_external" and external_approved)
def infer(row):
    d=str(row.get("domain") or row.get("alloy_family") or "").lower().replace("-","_").replace(" ","_")
    if d in TI|TMC|{"nonti_external"}: return d
    m=str(row.get("matrix") or row.get("matrix_family") or "").lower(); r=str(row.get("reinforcement") or row.get("reinforcement_phase") or "").lower()
    if m and "ti" not in m and "titan" not in m: return "nonti_external"
    if "tib" in r or "boride" in r: return "tmc_tib"
    if "tic" in r or "carbide" in r: return "tmc_tic"
    if "sic" in r and ("fib" in r): return "tmc_sic_fiber"
    if r: return "tmc_other"
    return "alpha_beta" if ("ti" in m or "titan" in m) else "nonti_external"
