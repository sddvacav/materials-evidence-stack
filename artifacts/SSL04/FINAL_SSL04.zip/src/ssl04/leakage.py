import hashlib,json
ID=("paper_uid","paper_doi","sample_uid","sample_id","batch_id","physical_specimen_id")
FP=("composition_normalized","process_route","heat_treatment","test_temperature_C","reinforcement_phase","reinforcement_fraction")
def group(r): return hashlib.sha256("|".join(str(r.get(k) or "").strip().lower() for k in ID).encode()).hexdigest()
def fp(r):
    payload={k:r.get(k) for k in FP}
    if not any(v not in (None,"") for v in payload.values()): return ""
    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
def purge(rows,test):
    gs={group(r) for r in test}; fs={x for r in test if (x:=fp(r))}; keep=[]; removed=[]
    for r in rows:
        x=fp(r)
        reason="IDENTITY_GROUP_OVERLAP" if group(r) in gs else ("NEAR_DUPLICATE_FINGERPRINT" if x and x in fs else "")
        (removed if reason else keep).append({"record_uid":r.get("record_uid", ""),"reason":reason} if reason else r)
    return keep,removed
