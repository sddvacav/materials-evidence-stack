from dataclasses import dataclass
from pathlib import Path
@dataclass(frozen=True)
class Config:
    authority_dir:Path; output_dir:Path; seeds:tuple=(1103,2207,3301,4409,5519); folds:int=5; inductive_only:bool=True
    def validate(self):
        if len(self.seeds)<5: raise ValueError("five seeds required")
        if self.folds<2: raise ValueError("folds >=2")
        if not self.inductive_only: raise ValueError("transductive runs require separate config")
