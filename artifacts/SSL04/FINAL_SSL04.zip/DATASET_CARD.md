# Dataset Card

Status `NOT_LOADED / BLOCKED_INPUT`. Formal labels must be frozen SCREENED_GOLD. Silver is sensitivity-only; Evidence-only and non-Ti records cannot be formal labels. Fold-local pretraining must purge all target-test identity and near-duplicate edges. No dataset statistic is reported because the authority release was absent.
