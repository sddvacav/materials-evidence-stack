No plot code executed.
