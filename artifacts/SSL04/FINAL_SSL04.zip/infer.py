#!/usr/bin/env python3
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument("--checkpoint",required=True); a=p.parse_args(); q=Path(a.checkpoint)
print(json.dumps({"status":"READY" if q.is_file() else "BLOCKED_INPUT","checkpoint":str(q)})); raise SystemExit(0 if q.is_file() else 42)
