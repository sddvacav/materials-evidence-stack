# Acceptance

`python -m zipfile -t FINAL_SSL04.zip`

`sha256sum -c FINAL_SSL04.sha256`

`python -m unittest discover -s tests -v`
