# Local absorption

Place one internally consistent MC01/MC02 release under `authority/`, verify its checksums, then run `./run_all.sh --authority authority --smoke` followed by the formal fold-local run. Do not alter snapshot, split, targets, seeds or budgets.
