# METHOD IR mirror
Canonical machine-readable cards are in DATA/g09/method_ir_catalog.jsonl. This mirror is not product apply scope.
