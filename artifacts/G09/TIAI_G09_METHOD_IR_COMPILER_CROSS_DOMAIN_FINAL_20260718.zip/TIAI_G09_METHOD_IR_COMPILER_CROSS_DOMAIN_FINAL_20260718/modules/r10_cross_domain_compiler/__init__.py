"""Ti/TMC cross-domain Method IR compiler."""
from .core import *
__version__="1.0.0"
