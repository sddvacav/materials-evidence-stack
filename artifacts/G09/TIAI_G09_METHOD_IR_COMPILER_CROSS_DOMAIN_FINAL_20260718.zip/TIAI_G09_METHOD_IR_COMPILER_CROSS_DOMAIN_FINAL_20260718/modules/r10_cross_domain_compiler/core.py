from __future__ import annotations
from dataclasses import dataclass,asdict
import hashlib,json,math,re
from pathlib import Path
from typing import Any,Sequence
@dataclass(frozen=True)
class FailureSignature:
 phase:str;code:str;observed:str;expected:str;protocol:str="unknown";metric_name:str="";adapter_id:str="";severity:str="medium";recurrence:int=1
@dataclass(frozen=True)
class GateOutcome:
 gate_id:str;passed:bool;reason:str
 def to_dict(self):return asdict(self)
def _finite(xs):
 v=[float(x) for x in xs]
 if not v or any(not math.isfinite(x) for x in v):raise ValueError("finite non-empty values required")
 return v
def weighted_quantile(values:Sequence[float],weights:Sequence[float],q:float)->float:
 if len(values)!=len(weights) or not values or not 0<=q<=1:raise ValueError("invalid weighted quantile input")
 z=sorted((float(v),float(w)) for v,w in zip(values,weights));total=sum(w for _,w in z)
 if total<=0 or any(w<0 for _,w in z):raise ValueError("positive non-negative weights required")
 a=0
 for v,w in z:
  a+=w
  if a>=q*total:return v
 return z[-1][0]
def split_conformal_radius(y,yhat,alpha=.1):
 if len(y)!=len(yhat) or not y or not 0<alpha<1:raise ValueError("invalid conformal input")
 s=sorted(abs(float(a)-float(b)) for a,b in zip(y,yhat));k=min(len(s)-1,math.ceil((len(s)+1)*(1-alpha))-1);return s[k]
def group_dro_update(weights,losses,eta=.1):
 if len(weights)!=len(losses) or not weights:raise ValueError("shape mismatch")
 z=[max(0,float(w))*math.exp(float(eta)*float(l)) for w,l in zip(weights,losses)];s=sum(z)
 if s<=0:return [1/len(z)]*len(z)
 return [x/s for x in z]
def _cov(rows):
 if len(rows)<2:raise ValueError("two rows required")
 d=len(rows[0]);x=[[float(v) for v in r] for r in rows]
 if d<1 or any(len(r)!=d for r in x):raise ValueError("rectangular rows required")
 m=[sum(r[j] for r in x)/len(x) for j in range(d)]
 return [[sum((r[i]-m[i])*(r[j]-m[j]) for r in x)/(len(x)-1) for j in range(d)] for i in range(d)]
def coral_penalty(a,b):
 ca,cb=_cov(a),_cov(b);d=len(ca)
 if len(cb)!=d:raise ValueError("dimension mismatch")
 return sum((ca[i][j]-cb[i][j])**2 for i in range(d) for j in range(d))/(4*d*d)
def eb_mean(group_mean,n,within_var,global_mean,tau2):
 if n<=0 or within_var<=0 or tau2<=0:raise ValueError("positive count/variance required")
 pd=n/within_var;pp=1/tau2;return (pd*group_mean+pp*global_mean)/(pd+pp)
def cvar(losses,alpha=.9):
 x=sorted(_finite(losses))
 if not 0<=alpha<1:raise ValueError("alpha range")
 k=min(len(x)-1,max(0,math.ceil(alpha*len(x))));return sum(x[k:])/len(x[k:])
def simplex_violation(comp,total=100.,tol=1e-6):
 x=[float(v) for v in comp.values()];neg=sum(max(0,-v) for v in x);err=abs(sum(x)-total);return {"valid":neg+err<=tol,"negative_mass":neg,"sum_error":err,"violation":neg+err}
def hypervolume2(points,ref):
 rx,ry=map(float,ref);p=[(float(x),float(y)) for x,y in points if x>rx and y>ry]
 xs=sorted({rx,*[x for x,_ in p]});return sum((hi-lo)*max(0,max([y for x,y in p if x>=hi],default=ry)-ry) for lo,hi in zip(xs[:-1],xs[1:]))
def expected_hvi(existing,samples,ref):
 if not samples:raise ValueError("samples required")
 b=hypervolume2(existing,ref);return sum(max(0,hypervolume2([*existing,s],ref)-b) for s in samples)/len(samples)
def generate_queries(f:FailureSignature,max_queries=8):
 blob=" ".join([f.phase,f.code,f.observed,f.expected,f.protocol,f.metric_name,f.adapter_id]).lower();base="titanium alloy titanium matrix composite"
 bank=[(("leak","source id"),"source-group leakage leave-one-source-out"),(("coverage","calibr"),"conformal calibration covariate shift"),(("ood","applicability"),"applicability domain out-of-distribution"),(("batch","laboratory"),"empirical Bayes cross-laboratory batch correction"),(("tail","worst"),"CVaR distributionally robust optimization"),(("constraint","simplex","ys>uts"),"physics constrained alloy design")]
 out=[]
 for keys,q in bank:
  if any(k in blob for k in keys):out.append({"query":base+" "+q+" primary paper benchmark implementation","failure_code":f.code})
 if not out:out=[{"query":base+" scientific ML failure diagnosis reproducibility primary paper","failure_code":f.code}]
 return out[:max(1,max_queries)]
def _nonempty(x):return x not in (None,"",[],{})
def evaluate(ir,policy):
 try:
  iso=ir["problem_contract"]["isomorphism"];eq=ir["mathematical_core"]["equations"];a=ir["adapter"];t=ir["tests"];s=ir["evaluation"]["split_protocol"];trust=ir["evaluation"];b=ir["benchmark"];ab=ir["absorption"]
  checks=[bool(ir["evidence"]["sources"]) and all(_nonempty(x.get("locator")) and any(_nonempty(x.get(k)) for k in ("url","doi","package_path")) for x in ir["evidence"]["sources"]),any(x.get("evidence_level") in {"primary","fulltext","project_verified","primary_or_fulltext"} for x in ir["evidence"]["sources"]),all(_nonempty(iso.get(k)) for k in ("state","action","observation","uncertainty","loss","constraints")),bool(eq) and all(_nonempty(x.get("expression")) and _nonempty(x.get("variables")) and _nonempty(x.get("assumptions")) and _nonempty(x.get("complexity")) for x in eq),bool(ir["mathematical_core"].get("contraindications")),a.get("implementation_status")=="implemented" and all(_nonempty(a.get(k)) for k in ("module_path","callable","python_signature","input_schema","output_schema")),t.get("executable") is True and {"unit","negative","metamorphic"}.issubset({x.get("type") for x in t.get("cases",[])}),"LOSO" in s["test_caliber"]["name"] and _nonempty(s["test_caliber"].get("grouping_key")) and bool(s.get("forbidden_features")),s["training_caliber"]["name"]!=s["test_caliber"]["name"] and s.get("headline_caliber")=="test_caliber",all(trust.get(k,{}).get("required") is True for k in ("uq","ood","ad","abstention")) and "fail_closed" in trust["abstention"].get("policy",""),b.get("receipt_required") is True and ir["promotion"].get("benchmark_receipt_binding") is True and _nonempty(b.get("receipt")),ab.get("retrieval_only") is False and ab.get("implementation_present") is True and ab.get("tests_present") is True and ab.get("benchmark_receipt_present") is True]
 except Exception:checks=[False]*12
 return [GateOutcome(g["gate_id"],bool(ok),"PASS" if ok else "FAIL_CLOSED") for g,ok in zip(policy["gates"],checks)]
def compile_ir(ir,policy):
 o=evaluate(ir,policy);bad=[x.gate_id for x in o if not x.passed];return {"method_id":ir.get("method_id"),"status":"compile_ready" if not bad else "rejected_fail_closed","failed_gates":bad}
def promote(outcomes,receipts,threshold=.9,min_seeds=5):
 if any(not x.passed for x in outcomes):return {"state":"rejected_fail_closed","claim_ceiling":"no_claim"}
 if receipts.get("unit_tests",{}).get("passed") is not True:return {"state":"blocked_missing_test_receipt","claim_ceiling":"adapter_candidate"}
 if "hq_loso" not in receipts:return {"state":"merge-ready-candidate","claim_ceiling":"merge-ready-candidate"}
 r=receipts["hq_loso"]
 if r.get("protocol")!="HQ_LOSO_SOURCE_HOLDOUT" or r.get("leakage_audit_pass") is not True or float(r.get("r2",-1))<threshold or int(r.get("n_seeds",0))<min_seeds or r.get("coverage_reported") is not True:return {"state":"below_gate_continue_optimization","claim_ceiling":"below_gate_continue_optimization"}
 return {"state":"production_candidate_pending_independent_release","claim_ceiling":"production_candidate_pending_independent_release"}
def fingerprint(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()
