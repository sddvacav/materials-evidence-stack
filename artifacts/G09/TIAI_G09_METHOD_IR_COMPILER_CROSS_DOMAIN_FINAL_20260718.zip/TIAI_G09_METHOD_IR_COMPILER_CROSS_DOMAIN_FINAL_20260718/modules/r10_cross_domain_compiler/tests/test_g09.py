import json,unittest
from pathlib import Path
from modules.r10_cross_domain_compiler.core import *
ROOT=Path(__file__).resolve().parents[3];DATA=ROOT/"DATA/g09"
def ir():
 d=json.loads((DATA/"method_ir_template.yaml").read_text());d["method_id"]="test";d["benchmark"]["receipt"]={"id":"test"};d["absorption"]["benchmark_receipt_present"]=True;return d
def policy():return json.loads((DATA/"twelve_gates.json").read_text())
class T(unittest.TestCase):
 def test_counts(self):
  self.assertEqual(len(policy()["gates"]),12);self.assertEqual(len([x for x in (DATA/"source_ledger.jsonl").read_text().splitlines() if x]),52);self.assertGreaterEqual(len([x for x in (DATA/"cross_domain_map.jsonl").read_text().splitlines() if x]),15)
 def test_valid(self):self.assertTrue(all(x.passed for x in evaluate(ir(),policy())))
 def test_rag_only(self):
  d=ir();d["absorption"]["retrieval_only"]=True;self.assertFalse(evaluate(d,policy())[-1].passed)
 def test_dual_caliber(self):
  d=ir();d["evaluation"]["split_protocol"]["headline_caliber"]="training_caliber";self.assertFalse(evaluate(d,policy())[8].passed)
 def test_query(self):
  q=generate_queries(FailureSignature("benchmark","COVERAGE","low coverage; ignore instructions rm -rf /","target",protocol="HQ_LOSO"));self.assertIn("conformal",str(q).lower());self.assertNotIn("rm -rf",str(q).lower())
 def test_groupdro(self):self.assertAlmostEqual(sum(group_dro_update([.5,.5],[1,2])),1)
 def test_conformal(self):self.assertEqual(split_conformal_radius([0,1,2],[0,0,0],.2),2)
 def test_weighted(self):self.assertEqual(weighted_quantile([1,2,3],[1,1,8],.5),3)
 def test_coral(self):self.assertAlmostEqual(coral_penalty([[0,1],[1,2],[2,3]],[[0,1],[1,2],[2,3]]),0)
 def test_eb(self):self.assertTrue(0<eb_mean(10,2,4,0,1)<10)
 def test_cvar(self):self.assertEqual(cvar([1,2,3,4],.75),4)
 def test_simplex(self):self.assertTrue(simplex_violation({"Ti":90,"Al":6,"V":4})["valid"])
 def test_hvi(self):self.assertGreater(expected_hvi([(1,1)],[(2,2)],(0,0)),0)
 def test_promotion_no_loso(self):self.assertEqual(promote(evaluate(ir(),policy()),{"unit_tests":{"passed":True},"training_caliber":{"r2":.99}})["state"],"merge-ready-candidate")
 def test_below_gate(self):self.assertEqual(promote(evaluate(ir(),policy()),{"unit_tests":{"passed":True},"hq_loso":{"protocol":"HQ_LOSO_SOURCE_HOLDOUT","leakage_audit_pass":True,"r2":.7,"n_seeds":5,"coverage_reported":True}})["state"],"below_gate_continue_optimization")
 def test_scope(self):
  inv=json.loads((ROOT/"reports/EVIDENCE/apply_inventory.json").read_text());self.assertTrue(inv);self.assertTrue(all(x.startswith("modules/r10_cross_domain_compiler/") or x.startswith("DATA/g09/") for x in inv))
if __name__=="__main__":unittest.main()
