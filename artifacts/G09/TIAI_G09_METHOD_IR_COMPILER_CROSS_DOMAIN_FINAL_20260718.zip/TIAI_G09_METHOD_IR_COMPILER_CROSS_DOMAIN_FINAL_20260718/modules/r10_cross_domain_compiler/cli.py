from __future__ import annotations
import argparse,json
from pathlib import Path
from .core import evaluate
def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument("--data-root",default="DATA/g09");a=p.parse_args(argv);r=Path(a.data_root)
 m=[json.loads(x) for x in (r/"cross_domain_map.jsonl").read_text().splitlines() if x];s=[json.loads(x) for x in (r/"source_ledger.jsonl").read_text().splitlines() if x];g=json.loads((r/"twelve_gates.json").read_text())
 out={"ok":len(m)>=15 and len(s)>=50 and len(g["gates"])==12 and g["fail_closed"] is True,"maps":len(m),"searches":len(s),"gates":len(g["gates"])};print(json.dumps(out,indent=2));return 0 if out["ok"] else 2
if __name__=="__main__":raise SystemExit(main())
