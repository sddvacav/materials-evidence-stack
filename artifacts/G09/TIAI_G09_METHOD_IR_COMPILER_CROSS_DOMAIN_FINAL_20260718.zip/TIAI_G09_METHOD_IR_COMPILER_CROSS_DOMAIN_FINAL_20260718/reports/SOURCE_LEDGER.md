# SOURCE_LEDGER — 52 English directed searches

|ID|Query|Source|Decision|
|---|---|---|---|
|Q01|GroupDRO worst-group optimization|Distributionally Robust Neural Networks for Group Shifts|absorb_or_prescreen|
|Q02|Deep CORAL covariance alignment|Deep CORAL|absorb_or_prescreen|
|Q03|Invariant Risk Minimization|Invariant Risk Minimization|absorb_or_prescreen|
|Q04|DomainBed benchmark|In Search of Lost Domain Generalization|absorb_or_prescreen|
|Q05|Conformalized quantile regression|Conformalized Quantile Regression|absorb_or_prescreen|
|Q06|Conformal risk control|Conformal Risk Control|absorb_or_prescreen|
|Q07|Weighted conformal covariate shift|Conformal Prediction Under Covariate Shift|absorb_or_prescreen|
|Q08|Adaptive conformal distribution shift|Adaptive Conformal Inference Under Distribution Shift|absorb_or_prescreen|
|Q09|FourCastNet weather forecasting|FourCastNet|absorb_or_prescreen|
|Q10|GraphCast weather graph model|GraphCast|absorb_or_prescreen|
|Q11|GenCast probabilistic weather|Probabilistic weather forecasting with machine learning|absorb_or_prescreen|
|Q12|WeatherBench2 benchmark|WeatherBench 2|absorb_or_prescreen|
|Q13|EnbPI time-series intervals|Ensemble Batch Prediction Intervals|absorb_or_prescreen|
|Q14|SPCI sequential conformal|Sequential Predictive Conformal Inference for Time Series|absorb_or_prescreen|
|Q15|Conformal time-series drift|Conformal Time-Series Forecasting search|absorb_or_prescreen|
|Q16|Hierarchical risk parity|Building Diversified Portfolios that Outperform Out of Sample|absorb_or_prescreen|
|Q17|Distributionally robust portfolio|Distributionally Robust Portfolio Optimization|absorb_or_prescreen|
|Q18|Conformal portfolio selection|Conformal Prediction for Portfolio Selection|absorb_or_prescreen|
|Q19|CVaR portfolio optimization|Portfolio Optimization with Conditional Value-at-Risk Objective|absorb_or_prescreen|
|Q20|Matbench materials benchmark|Matbench|absorb_or_prescreen|
|Q21|CrabNet materials prediction|CrabNet|absorb_or_prescreen|
|Q22|ALIGNN materials graph|ALIGNN|absorb_or_prescreen|
|Q23|MODNet small materials data|MODNet|absorb_or_prescreen|
|Q24|ComBat empirical Bayes|Adjusting batch effects using empirical Bayes|absorb_or_prescreen|
|Q25|ComBat-seq distribution-specific batch|ComBat-seq|absorb_or_prescreen|
|Q26|Batch correction overcorrection benchmark|Benchmarking batch effect correction methods|absorb_or_prescreen|
|Q27|Cross-lab batch correction evaluation|Systematic evaluation of batch correction|absorb_or_prescreen|
|Q28|TabPFN small tabular foundation model|Accurate predictions on small data with a tabular foundation model|absorb_or_prescreen|
|Q29|FT-Transformer tabular benchmark|Revisiting Deep Learning Models for Tabular Data|absorb_or_prescreen|
|Q30|SAINT row attention|SAINT|absorb_or_prescreen|
|Q31|TabNet interpretability|TabNet|absorb_or_prescreen|
|Q32|qNEHVI noisy multi-objective BO|Parallel Bayesian Optimization of Multiple Noisy Objectives with Expected Hypervolume Improvement|absorb_or_prescreen|
|Q33|Multi-fidelity max-value entropy search|Multi-fidelity Bayesian Optimization with Max-value Entropy Search|absorb_or_prescreen|
|Q34|Constrained Bayesian optimization|Bayesian Optimization with Inequality Constraints|absorb_or_prescreen|
|Q35|Robust multi-objective BO input noise|Robust Multi-Objective Bayesian Optimization Under Input Noise|absorb_or_prescreen|
|Q36|BALD active learning|Bayesian Active Learning for Classification and Preference Learning|absorb_or_prescreen|
|Q37|BatchBALD diverse batch acquisition|BatchBALD|absorb_or_prescreen|
|Q38|Prediction-oriented active learning|Prediction-Oriented Bayesian Active Learning|absorb_or_prescreen|
|Q39|Closed-loop autonomous materials discovery|Closed-loop materials discovery|absorb_or_prescreen|
|Q40|Datasheets for Datasets|Datasheets for Datasets|absorb_or_prescreen|
|Q41|Model Cards reporting|Model Cards for Model Reporting|absorb_or_prescreen|
|Q42|Hidden technical debt ML systems|Hidden Technical Debt in Machine Learning Systems|absorb_or_prescreen|
|Q43|NeurIPS reproducibility guidance|NeurIPS Main Track Handbook|absorb_or_prescreen|
|Q44|NIST AI RMF generative confabulation|NIST AI RMF Generative AI Profile|absorb_or_prescreen|
|Q45|JSON Schema 2020-12|JSON Schema Draft 2020-12|absorb_or_prescreen|
|Q46|Metamorphic testing ML|METTLE|absorb_or_prescreen|
|Q47|Croissant ML dataset metadata|Croissant|absorb_or_prescreen|
|Q48|GroupDRO primary verification|Distributionally Robust Neural Networks for Group Shifts|absorb_or_prescreen|
|Q49|qNEHVI primary verification|qNEHVI|absorb_or_prescreen|
|Q50|Model Cards primary verification|Model Cards|absorb_or_prescreen|
|Q51|Hidden debt primary verification|Hidden Technical Debt|absorb_or_prescreen|
|Q52|Ti alloy ML uncertainty OOD|Materials informatics uncertainty qualification search|absorb_or_prescreen|
