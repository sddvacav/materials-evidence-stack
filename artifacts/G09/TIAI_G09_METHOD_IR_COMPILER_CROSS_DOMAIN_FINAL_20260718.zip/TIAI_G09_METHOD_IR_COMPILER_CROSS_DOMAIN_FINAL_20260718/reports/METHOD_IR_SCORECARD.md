# Scorecard

- English searches: 52
- Cross-domain maps: 20
- Method IR cards: 12
- Fail-closed gates: 12
- HQ-LOSO performance receipts: 0
- Claim ceiling: merge-ready-candidate
