# Platform dimensions

1. Frontier algorithms: 12 executable IR cards and 20 structural maps.
2. Mathematical trust: 12 non-compensatory gates and dual-caliber promotion.
3. Multi-domain utilization: ICML, ICMS, weather, quant and batch-effect structures mapped only to Ti/TMC targets.

No R² or 800 °C claim.
