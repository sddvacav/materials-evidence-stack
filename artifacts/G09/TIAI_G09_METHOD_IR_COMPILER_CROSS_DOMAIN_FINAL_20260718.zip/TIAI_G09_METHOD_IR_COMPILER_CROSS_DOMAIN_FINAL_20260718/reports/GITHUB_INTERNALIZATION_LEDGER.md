# Internalization ledger

No third-party code vendored. DomainBed, BoTorch/qNEHVI, TabPFN and WeatherBench concepts are represented as contracts or small standard-library primitives; adoption requires license/dependency review and same-boundary replay.
