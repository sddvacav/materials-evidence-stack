# G09 DESIGN

Absorption chain: primary evidence → explicit problem isomorphism → equation/assumptions → executable adapter → unit/negative/metamorphic tests → locked dual-caliber benchmark → immutable receipt-bound promotion. RAG-only is rejected by Gate G12.

Implemented kernels: GroupDRO O(G), CORAL O(nd²), split/weighted conformal O(n log n), empirical-Bayes source shrinkage O(1)/group, CVaR O(n log n), simplex feasibility, exact 2-D hypervolume and sampled HVI. All fitted transforms are training-fold-only.

LLM is permitted to propose queries and draft IR; it cannot create scientific truth, benchmark receipts, promotion decisions or property values.
