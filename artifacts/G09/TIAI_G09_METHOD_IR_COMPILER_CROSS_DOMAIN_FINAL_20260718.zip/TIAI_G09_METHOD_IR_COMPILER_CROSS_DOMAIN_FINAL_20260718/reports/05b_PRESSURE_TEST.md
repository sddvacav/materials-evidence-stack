# Pressure tests

1. Missing formula → fail closed.
2. retrieval_only=true → G12 fail.
3. GE5 headline substitution → G09 fail.
4. prompt injection in failure text is not copied.
5. high train R² without HQ-LOSO stays merge-ready-candidate.
6. below-gate HQ-LOSO stays below_gate_continue_optimization.
