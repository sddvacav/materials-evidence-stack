# LOCAL CODEX APPLY — 0.01%

```powershell
$pkg="<UNZIP_DIR>\TIAI_G09_METHOD_IR_COMPILER_CROSS_DOMAIN_FINAL_20260718"
$repo="E:\Generated\tiai-agent-os"
Set-Location $repo
git apply --check "$pkg\PATCHES\R10_CROSS_DOMAIN_METHOD_COMPILER.patch"
git apply "$pkg\PATCHES\R10_CROSS_DOMAIN_METHOD_COMPILER.patch"
python -m compileall -q modules\r10_cross_domain_compiler
python -m unittest discover -s modules\r10_cross_domain_compiler\tests -p "test_*.py" -v
python -m modules.r10_cross_domain_compiler.cli --data-root DATA\g09
```

Local does not re-extract literature, redesign architecture or retrain.
