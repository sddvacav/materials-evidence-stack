# CLAIM BOUNDARY

Can claim executable compiler candidate, 12 gates, 52-search ledger, 20 maps, 12 cards. Cannot claim Ti/TMC accuracy gain, HQ-LOSO ≥0.9, FULLSCORE, PRODUCTION_CHAMPION or 800 °C readiness.
