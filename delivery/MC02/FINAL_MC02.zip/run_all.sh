#!/usr/bin/env bash
set -euo pipefail
python -m unittest discover -s tests -v
python src/validate_package.py --package .
python src/resume.py
python src/infer.py
