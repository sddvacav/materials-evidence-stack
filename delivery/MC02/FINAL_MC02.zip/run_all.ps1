$ErrorActionPreference='Stop'
py -m unittest discover -s tests -v
py src/validate_package.py --package .
py src/resume.py
py src/infer.py
