# Open Issues

1. Supply and hash-verify:
- `v31/control/MC01/MODEL_INPUT_SNAPSHOT.json`
- `v31/control/MC01/SPLIT_AUTHORITY.json`
- `v31/control/MC01/SEED_REGISTRY.json`
- `v31/gold/SCREENED_GOLD.parquet`
- `v29/ATOMIC_RECORDS.parquet`
- `v29/PROVENANCE.jsonl`
- `v29/CONFLICT_LEDGER.csv`
2. Recompute full-file SHA-256 and testzip for current suffixed V27 uploads and reconcile prior canonical fingerprints.
3. Resolve proof-stress method for records labeled only YS.
4. Bind every row to paper/sample/condition/source locator and hash.
5. Run duplicate/same-physical-specimen grouping audit before split consumption.