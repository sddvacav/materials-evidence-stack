from __future__ import annotations
import argparse,csv,hashlib,json,re
from pathlib import Path
import pyarrow.parquet as pq
REQUIRED=['00_EXECUTIVE_VERDICT.md', 'SOURCE_UTILIZATION_MATRIX.csv', 'PRIMARY_LITERATURE_AUDIT.csv', 'INPUT_LEDGER.csv', 'DATASET_CARD.md', 'RUN_CONFIG.yaml', 'ENVIRONMENT_LOCK.txt', 'TRAINING_LOG.jsonl', 'OOF_PREDICTIONS.parquet', 'METRICS_BY_FOLD.csv', 'METRICS_BY_SEED.csv', 'ERROR_ANALYSIS.csv', 'MODEL_CARD.md', 'METHODS.md', 'LIMITATIONS.md', 'NEGATIVE_RESULTS.md', 'OPEN_ISSUES.md', 'WEB_TO_LOCAL_REQUEST.json', 'LOCAL_ABSORPTION_PROMPT.md', 'WINDOW_STATUS.json', 'MANIFEST.json', 'CHECKSUMS.sha256', 'TARGET_SEMANTICS.csv', 'FEATURE_REGISTRY.csv', 'FEATURE_FIREWALL.md', 'PREPROCESSING_CONTRACT.json', 'MISSINGNESS_POLICY.md', 'COMPOSITION_CONSTRAINTS.md', 'TARGET_TASK_MATRIX.csv', 'ORIGINAL_PAPER_SEMANTIC_CHECK.csv', 'README.md', 'DESIGN.md', 'ACCEPTANCE_COMMANDS.md', 'requirements.lock', 'run_all.sh', 'run_all.ps1', 'configs/mc02.yaml', 'src/__init__.py', 'src/mc02_contract.py', 'src/build_training_table.py', 'src/validate_package.py', 'src/resume.py', 'src/infer.py', 'tests/test_contract.py', 'artifacts/CONTROL_CONTRACT.json', 'artifacts/OOF_SCHEMA.json', 'artifacts/README.md', 'artifacts/checkpoints/README.md', 'TEST_REPORT.txt', 'VALIDATION_REPORT.json']
ALLOWED={'USED_DIRECTLY','USED_AS_REFERENCE','SUPERSEDED_BY_HASH','OUT_OF_SCOPE','BLOCKED_CORRUPT','NOT_RELEVANT_TO_WINDOW'}
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--package',type=Path,default=Path('.'));args=parser.parse_args();root=args.package.resolve();errors=[]
 missing=sorted(rel for rel in REQUIRED if not (root/rel).is_file())
 if missing:errors.append({'missing_required':missing})
 checks={}
 if (root/'CHECKSUMS.sha256').is_file():
  for line in (root/'CHECKSUMS.sha256').read_text().splitlines():
   if line.strip():digest,rel=line.split('  ',1);checks[rel]=digest
  for rel,digest in checks.items():
   path=root/rel
   if not path.is_file() or sha(path)!=digest:errors.append({'checksum_mismatch':rel})
 for rel in ['METRICS_BY_FOLD.csv','METRICS_BY_SEED.csv','ERROR_ANALYSIS.csv']:
  with (root/rel).open(newline='') as handle:
   rows=list(csv.reader(handle))
   if len(rows)!=1:errors.append({'nonempty_schema_only_file':rel,'rows':len(rows)-1})
 with (root/'SOURCE_UTILIZATION_MATRIX.csv').open(newline='') as handle:
  for row in csv.DictReader(handle):
   if row['terminal_use_status'] not in ALLOWED:errors.append({'invalid_state':row})
 with (root/'FEATURE_REGISTRY.csv').open(newline='') as handle:
  for row in csv.DictReader(handle):
   if row['firewall_status']=='BLOCK' and row['allowed_headline']=='true':errors.append({'blocked_allowed':row['canonical_name']})
 with (root/'TARGET_TASK_MATRIX.csv').open(newline='') as handle:
  rows=list(csv.DictReader(handle));ids=[row['task_id'] for row in rows]
  if len(ids)!=len(set(ids)):errors.append('duplicate tasks')
  if any(row['status']!='BLOCKED_INPUT_GATE' for row in rows):errors.append('task gate open')
 oof=pq.read_table(root/'OOF_PREDICTIONS.parquet')
 if oof.num_rows!=0:errors.append({'oof_rows':oof.num_rows})
 status=json.loads((root/'WINDOW_STATUS.json').read_text())
 if status.get('status')!='BLOCKED_INPUT' or status.get('snapshot_id') is not None or status.get('training_performed') is not False:errors.append({'bad_status':status})
 archives=[path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file() and path.suffix.lower() in {'.zip','.7z','.tar','.gz'}]
 if archives:errors.append({'nested_archives':archives})
 secret_patterns=[re.compile(r'sk-[A-Za-z0-9]{20,}'),re.compile(r'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY'),re.compile(r'ghp_[A-Za-z0-9]{30,}')]
 for path in root.rglob('*'):
  if path.is_file() and path.suffix.lower()!='.parquet':
   try:text=path.read_text(errors='ignore')
   except Exception:continue
   if any(pattern.search(text) for pattern in secret_patterns):errors.append({'secret_pattern':path.relative_to(root).as_posix()})
 result={'pass':not errors,'errors':errors,'files':sum(1 for path in root.rglob('*') if path.is_file()),'oof_rows':oof.num_rows}
 print(json.dumps(result,indent=2,sort_keys=True));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
