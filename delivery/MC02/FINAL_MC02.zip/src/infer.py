import json
if __name__=='__main__':print(json.dumps({'window':'MC02','status':'NO_MODEL_CONTROL_WINDOW','predictions':[]},indent=2))
