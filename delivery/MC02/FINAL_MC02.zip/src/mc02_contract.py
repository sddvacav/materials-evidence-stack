from __future__ import annotations
import math
from typing import Iterable, Mapping
MISSING_CODES={'OBSERVED','EXPLICIT_ZERO','NOT_REPORTED','NOT_APPLICABLE','BELOW_DETECTION','STRUCTURAL_MISSING','AMBIGUOUS'}
FORBIDDEN_TOKENS=('post_test','post_fracture','fracture_morphology','necking','post_tem','post_dislocation','post_drx','strength_ductility_product','delta_uts','delta_ys','delta_el','oof_residual','shap_value','model_prediction')
TARGET_NAMES={'uts_mpa','ys_mpa','elongation_pct','hardness','modulus_gpa','y_true','target'}
def normalize_temperature(value:float,unit:str)->float:
 u=unit.strip().lower().replace('°','')
 if u in {'c','degc','celsius'}:return float(value)
 if u in {'k','kelvin'}:return float(value)-273.15
 raise ValueError('unsupported temperature unit')
def normalize_stress_to_mpa(value:float,unit:str)->float:
 u=unit.strip().lower()
 if u=='mpa':return float(value)
 if u=='gpa':return float(value)*1000
 if u=='pa':return float(value)/1e6
 raise ValueError('unsupported stress unit')
def build_task_key(target,test_mode,temperature_protocol,direction,strain_rate_protocol):
 vals=[target,test_mode,temperature_protocol,direction or 'UNKNOWN',strain_rate_protocol or 'UNKNOWN']
 if any('|' in str(v) for v in vals):raise ValueError('delimiter in component')
 return '|'.join(str(v).strip() for v in vals)
def validate_composition_closure(values:Mapping[str,float|None],complete:bool,tolerance:float=0.5):
 observed=[float(v) for v in values.values() if v is not None];total=sum(observed)
 if any(v<0 or v>100 for v in observed):return False,total
 return ((abs(total-100)<=tolerance) if complete else True),total
def classify_missing(value,explicit_zero=False,applicable=True,below_detection=False,ambiguous=False):
 if ambiguous:return 'AMBIGUOUS'
 if not applicable:return 'NOT_APPLICABLE'
 if below_detection:return 'BELOW_DETECTION'
 if explicit_zero:return 'EXPLICIT_ZERO'
 if value is None or (isinstance(value,float) and math.isnan(value)):return 'NOT_REPORTED'
 return 'OBSERVED'
def firewall_decision(feature_name,availability_time='before_test'):
 name=feature_name.strip().lower()
 if name in TARGET_NAMES or any(token in name for token in FORBIDDEN_TOKENS):return False,'label/proxy/post-test/model-derived'
 if availability_time in {'after_target_observed','post_test','post_model'}:return False,'unavailable before target'
 if name in {'paper_uid','sample_uid','condition_uid','doi'}:return False,'grouping key only'
 return True,'eligible subject to registry tier'
def assert_fit_scope(fit_row_ids:Iterable[str],outer_train_ids:Iterable[str]):
 leaked=set(fit_row_ids)-set(outer_train_ids)
 if leaked:raise ValueError('fit outside outer train: '+str(sorted(leaked)[:5]))
def validate_fraction_basis(precursor_basis,actual_phase_basis):
 valid={None,'wt_pct','vol_pct','mass_fraction','volume_fraction'}
 if precursor_basis not in valid or actual_phase_basis not in valid:raise ValueError('unsupported basis')
 if precursor_basis=='actual_phase' or actual_phase_basis=='precursor':raise ValueError('conflated')
def can_merge_modulus(method_a,method_b):return method_a.strip().lower()==method_b.strip().lower()
