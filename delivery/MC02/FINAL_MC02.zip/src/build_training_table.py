from __future__ import annotations
import argparse,json
from pathlib import Path
import pyarrow.parquet as pq
REQUIRED=['v31/control/MC01/MODEL_INPUT_SNAPSHOT.json','v31/control/MC01/SPLIT_AUTHORITY.json','v31/control/MC01/SEED_REGISTRY.json','v31/gold/SCREENED_GOLD.parquet','v29/ATOMIC_RECORDS.parquet','v29/PROVENANCE.jsonl','v29/CONFLICT_LEDGER.csv']
def main():
 p=argparse.ArgumentParser();p.add_argument('--authority-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 missing=[rel for rel in REQUIRED if not (a.authority_root/rel).is_file()]
 if missing:print(json.dumps({'status':'BLOCKED_INPUT','missing':missing},indent=2));return 2
 snapshot=json.loads((a.authority_root/REQUIRED[0]).read_text())
 if not snapshot.get('snapshot_sha256'):print(json.dumps({'status':'BLOCKED_INPUT','reason':'snapshot_sha256 absent'},indent=2));return 2
 table=pq.read_table(a.authority_root/'v31/gold/SCREENED_GOLD.parquet');a.output.parent.mkdir(parents=True,exist_ok=True);pq.write_table(table,a.output,compression='zstd')
 print(json.dumps({'status':'MATERIALIZED_WITHOUT_PREPROCESSOR_FIT','rows':table.num_rows,'snapshot_sha256':snapshot['snapshot_sha256']},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
