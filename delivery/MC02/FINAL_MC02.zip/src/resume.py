import json
if __name__=='__main__':print(json.dumps({'window':'MC02','status':'NOT_APPLICABLE_CONTROL_WINDOW','checkpoint':None},indent=2))
