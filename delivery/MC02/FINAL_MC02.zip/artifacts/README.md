This directory contains control artifacts only. No model or fitted preprocessor is present.
