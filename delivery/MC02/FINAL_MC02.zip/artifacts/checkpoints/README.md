No checkpoint is applicable. Creating one in MC02 would violate the W0 boundary.
