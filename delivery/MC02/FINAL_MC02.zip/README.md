# FINAL_MC02

MC02 freezes target semantics, feature eligibility, preprocessing, missingness and composition constraints. It is executable and testable but intentionally blocked from training until MC01/V29 authorities are supplied. Run `./run_all.sh` on Linux/WSL2 or `powershell -ExecutionPolicy Bypass -File run_all.ps1` on Windows.