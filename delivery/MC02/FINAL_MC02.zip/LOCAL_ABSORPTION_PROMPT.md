# Local Absorption Prompt

Verify `CHECKSUMS.sha256`, run `run_all`, and keep `BLOCKED_INPUT` until all authority files below are mounted and hash-verified:
- `v31/control/MC01/MODEL_INPUT_SNAPSHOT.json`
- `v31/control/MC01/SPLIT_AUTHORITY.json`
- `v31/control/MC01/SEED_REGISTRY.json`
- `v31/gold/SCREENED_GOLD.parquet`
- `v29/ATOMIC_RECORDS.parquet`
- `v29/PROVENANCE.jsonl`
- `v29/CONFLICT_LEDGER.csv`
After unblocking, materialize from `SCREENED_GOLD` only, consume MC01 fold assignments unchanged and fit preprocessing inside each outer training fold. Do not mutate ACTIVE/Gold/Schema, register a model or label a candidate VALIDATED.