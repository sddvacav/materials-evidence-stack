# Acceptance Commands

Linux/WSL2: `python -m pip install -r requirements.lock && ./run_all.sh`.
Windows: `py -m pip install -r requirements.lock; powershell -ExecutionPolicy Bypass -File .\run_all.ps1`.
Expected state is `BLOCKED_INPUT`; all contract tests and package validation pass. Nonzero exit means corruption or contract violation.