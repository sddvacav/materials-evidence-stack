# Acceptance commands
```bash
python plot_code/plot_all.py
python -m unittest discover -s tests -v
python - <<'PY'
from pathlib import Path
import hashlib
root=Path('.')
for line in (root/'CHECKSUMS.sha256').read_text().splitlines():
    digest, rel=line.split('  ',1)
    assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest, rel
print('CHECKSUMS_OK')
PY
```
