# LOCAL ABSORPTION PROMPT — QM21
1. Verify FINAL_QM21.zip SHA-256 and extract into exclusive q40/QM21 staging. Do not modify ACTIVE/Gold/production registries.
2. Replace every provisional UID only through authoritative V29 maps; emit one-to-one crosswalk and reject ambiguity.
3. Bind every input to Q40_INPUT_SNAPSHOT.json, archive SHA-256 and member hash; no PENDING disposition.
4. Supply Xiong Table S1/Fig. S1, validated Koo numeric data, replicate uncertainty and actual phase fractions in WEB_TO_LOCAL_REQUEST.json.
5. Fit the declared mixed model only after support gates pass; execute paper-cluster bootstrap, LOPO and leave-family/grade-out. OOD grades remain hypotheses.
6. Run `python -m unittest discover -s tests -v`, regenerate figures, validate MANIFEST/CHECKSUMS and issue a new immutable package.
7. Never promote this web return to Gold or register a production SUP/SSL model from it.
