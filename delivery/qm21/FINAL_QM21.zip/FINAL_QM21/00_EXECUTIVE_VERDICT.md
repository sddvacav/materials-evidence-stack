# QM21 执行裁决：基体族异质性与跨牌号迁移

## 一句话结论
同一种名义增强相不存在可跨牌号直接搬运的“固有强化系数”。现有证据支持同论文成对效应（Claim Level 2），不支持把 cp-Ti、Ti-6Al-4V、near-alpha、Ti65 与 beta 合金拼成可外推的 family CATE。

## 可复算锚点
- cp-Ti / 13.56 vol.% TiC+TiB：室温 YS +89.3%，UTS +74.0%；EL 由表中 29% 降至 2.6%（正文另报 32.4%，已记冲突）。这是低基线、高混杂增强体积分数、挤压取向和强界面的极端锚点，不是纯 TiB 系数。
- Ti-6Al-4V / TiBw：图读数显示 1 vol.% TiBw 的 YS 增益随长径比约 18→58 显著增加；形貌/取向可压过名义剂量。图读数未进入推断性合并。
- near-alpha TA6.5 / 0.2 wt.% B：25 C 下 UTS +6.41%、YS +9.26%、EL -6.6 个百分点；650 C 下 UTS +5.79%、YS +10.58%、EL -6.0 个百分点。
- near-alpha 高温合金 / 3 vol.% TiB：室温压缩屈服 +19.2%，微区硬度 +14.4%；alpha 层片约 3→1.5 um、长度约 35→20 um，细晶与局部载荷阻滞是核心贡献。
- Ti65 / 3.4 vol.% TiBw：主文只允许保留 600 C UTS +17%、700 C +16%。Table S1/Fig. S1 缺失，绝对增益、方差和预测区间不得编造。
- Beta 21S / TiB+TiC：压缩强度随 B4C 前驱体剂量先升后降，1.5 wt.% 达峰、3 wt.% 回落，否定“剂量越高越强”。

## 第一性机制
`Delta sigma = Delta sigma_grain + Delta sigma_load-transfer + Delta sigma_dislocation/CTE + Delta sigma_phase/precipitation - Delta sigma_damage`

基体流动应力、alpha/beta 相分数、晶粒/层片尺度、TiB 长径比与取向、网络结构、界面质量、剂量、工艺和温度共同决定净收益。

## 迁移裁决
- family random slope、跨牌号效应方差、baseline moderation slope：NOT_IDENTIFIABLE。
- LOPO/leave-family-out：多数折删除后该家族没有剩余独立论文，FAILED_SUPPORT。
- 源牌号→目标牌号非对角迁移误差：全部留空；图中只显示 OOD，不伪造数字。
- 当前包不得晋升 Gold、不得注册生产模型、不得生成 VALIDATED 配方。
