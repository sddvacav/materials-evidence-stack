# FINAL_QM21
Quantitative return for matrix-family heterogeneity and cross-grade transfer of TiB/TiBw-containing titanium matrix composites.

Run:
```bash
python plot_code/plot_all.py
python -m unittest discover -s tests -v
```

Boundary: within-paper effects and OOD diagnostics only. No identified family CATE, numeric off-diagonal transfer error, production model, Gold promotion or validated recipe.
