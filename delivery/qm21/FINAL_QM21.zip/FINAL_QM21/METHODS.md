# METHODS

## Estimands
1. `DeltaY = Y_TMC - Y_matrix`.
2. `lnRR = ln(Y_TMC/Y_matrix)` for positive quantities.
3. `100*(exp(lnRR)-1)`.
4. Requested but not identified: family CATE, between-grade variance, baseline moderation slope and source-to-target transfer error.

## Atomicity and matching
One row is paper × sample × actual composition × precursor/actual phase × process × heat treatment × microstructure state × test mode × temperature × property. Tensile/compression, temperature, process and heat-treatment states were never merged. Grade A is same-paper/same-condition control; Grade B is evidence-limited matched contrast.

## Uncertainty
Where both arms reported SDs, conservative independent-arm approximations were used: `SE(Delta)=sqrt(SD_TMC^2+SD_matrix^2)` and `SE(lnRR)=sqrt((SD_TMC/Y_TMC)^2+(SD_matrix/Y_matrix)^2)`. Paired covariance is unavailable. SD was never reverse-engineered.

## Hierarchical model gate
The preregistered skeleton was retained but not fitted: `g(E[Y]) = beta0 + beta_r*reinforcement + f(dose) + beta_m*matrix + beta_p*process + beta_t*condition + interactions + u_paper + u_matrix + epsilon`. Matrix family is effectively aliased with paper, route, property mode, reinforcement identity and dose basis. Fitting would manufacture precision.

## Baseline moderation
The panel is observation-level only. Baseline appears in both denominator and contrast, creating mathematical coupling/regression-to-mean risk; paper/process/property mode remain confounded.

## Transfer and AD
Leave-grade/family-out needs a common frozen feature matrix, labels, official split manifest and target observations. Missing inputs make off-diagonal errors non-identifiable. The overlap map is a transparent six-dimension diagnostic, not a learned probability.

## Reproducibility
Every quantitative figure has CSV data and Python code. `plot_code/plot_all.py` regenerates SVG/PDF/600 dpi PNG. Tests enforce schemas, provenance, claim ceiling and blank off-diagonal transfer errors.
