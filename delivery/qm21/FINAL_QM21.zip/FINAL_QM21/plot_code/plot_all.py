from pathlib import Path
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"figure_data"; OUT=ROOT/"figures"; OUT.mkdir(exist_ok=True)
def read(name):
    with (DATA/name).open(encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))
def save(fig, stem):
    fig.savefig(OUT/f"{stem}.svg", bbox_inches="tight")
    fig.savefig(OUT/f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(OUT/f"{stem}.png", dpi=600, bbox_inches="tight")
    plt.close(fig)
def f1():
    d=sorted(read("F1_matrix_specific_effect_caterpillar.csv"), key=lambda r: float(r["percent_change"]))
    y=np.arange(len(d)); v=[float(r["percent_change"]) for r in d]
    fig,ax=plt.subplots(figsize=(11,max(7,0.39*len(d))))
    for i,r in enumerate(d):
        if r["ci95_low"] and r["ci95_high"]:
            ax.errorbar(v[i],y[i],xerr=[[v[i]-float(r["ci95_low"])],[float(r["ci95_high"])-v[i]]],fmt="o",capsize=3)
        else: ax.plot(v[i],y[i],"o")
    ax.axvline(0,lw=1); ax.set_yticks(y,[r["label"] for r in d]); ax.set_xlabel("Paired strength change (%)")
    ax.set_title("Matrix-specific reinforcement effects | 6 independent papers | Claim ceiling 2\nConservative CI only where both-arm SDs were reported")
    ax.grid(axis="x",alpha=.25); save(fig,"F1_matrix_specific_reinforcement_effect_caterpillar")
def f2():
    d=[r for r in read("F2_baseline_strength_gain.csv") if r["baseline_strength"] and r["percent_gain"]]
    fig,ax=plt.subplots(figsize=(10,7))
    for r in d:
        x=float(r["baseline_strength"]); y=float(r["percent_gain"]); ax.scatter([x],[y])
        ax.annotate(f"{r['grade']} {r['property'].replace('_MPa','')} {r['temperature_c']}C",(x,y),xytext=(4,4),textcoords="offset points",fontsize=7)
    ax.set_xlabel("Baseline matrix strength (MPa)"); ax.set_ylabel("Paired strength gain (%)")
    ax.set_title("Baseline strength versus reinforcement gain | Observation-level only\nNo moderation slope: confounding and regression-to-mean risk")
    ax.grid(alpha=.25); save(fig,"F2_baseline_strength_gain_relation")
def matrix_data(name, value):
    d=read(name); grades=[]
    for r in d:
        if r["source_grade"] not in grades: grades.append(r["source_grade"])
    idx={g:i for i,g in enumerate(grades)}; m=np.zeros((len(grades),len(grades)))
    for r in d: m[idx[r["source_grade"]],idx[r["target_grade"]]]=value(r)
    return d,grades,m
def f3():
    d,g,m=matrix_data("F3_grade_transfer_error_matrix.csv",lambda r:1.0 if r["source_grade"]==r["target_grade"] else 0.0)
    fig,ax=plt.subplots(figsize=(12,10)); ax.imshow(m)
    for i in range(len(g)):
        for j in range(len(g)): ax.text(j,i,"SELF" if i==j else "OOD",ha="center",va="center",fontsize=8)
    ax.set_xticks(range(len(g)),g,rotation=35,ha="right"); ax.set_yticks(range(len(g)),g)
    ax.set_xlabel("Target grade"); ax.set_ylabel("Source grade")
    ax.set_title("Grade-transfer error matrix | Numeric errors NOT IDENTIFIABLE\nOff-diagonal cells are support failures, not predictions")
    save(fig,"F3_grade_transfer_error_matrix")
def f4():
    d,g,m=matrix_data("F4_overlap_ad_map.csv",lambda r:float(r["overlap_score_descriptive"]))
    fig,ax=plt.subplots(figsize=(12,10)); im=ax.imshow(m,vmin=0,vmax=1)
    for i in range(len(g)):
        for j in range(len(g)): ax.text(j,i,f"{m[i,j]:.2f}",ha="center",va="center",fontsize=8)
    ax.set_xticks(range(len(g)),g,rotation=35,ha="right"); ax.set_yticks(range(len(g)),g)
    ax.set_xlabel("Target grade"); ax.set_ylabel("Source grade")
    ax.set_title("Overlap / applicability-domain map | Transparent six-dimension match score\nFamily, mode, temperature, reinforcement, dose basis and process")
    fig.colorbar(im,ax=ax,label="Descriptive overlap score"); save(fig,"F4_overlap_applicability_domain_map")
def main(): f1(); f2(); f3(); f4()
if __name__=="__main__": main()
