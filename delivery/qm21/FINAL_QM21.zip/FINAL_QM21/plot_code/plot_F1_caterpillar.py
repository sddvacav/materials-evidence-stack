from plot_all import f1
if __name__ == '__main__': f1()
