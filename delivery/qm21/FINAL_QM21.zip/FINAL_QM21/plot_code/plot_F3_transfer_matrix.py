from plot_all import f3
if __name__ == '__main__': f3()
