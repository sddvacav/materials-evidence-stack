from plot_all import f4
if __name__ == '__main__': f4()
