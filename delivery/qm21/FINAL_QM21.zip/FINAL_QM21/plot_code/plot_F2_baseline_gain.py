from plot_all import f2
if __name__ == '__main__': f2()
