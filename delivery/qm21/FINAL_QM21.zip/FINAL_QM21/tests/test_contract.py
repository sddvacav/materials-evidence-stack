import csv, hashlib, json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Contract(unittest.TestCase):
    def test_required_files(self):
        req=["00_EXECUTIVE_VERDICT.md","INPUT_LEDGER.csv","ANALYSIS_COHORT.csv","PAIR_MATCHES.csv","EFFECT_ESTIMATES.csv","HIERARCHICAL_RESULTS.csv","DOSE_RESPONSE.csv","INTERACTION_EFFECTS.csv","HETEROGENEITY.csv","SENSITIVITY_ANALYSIS.csv","NULL_NEGATIVE_RESULTS.csv","CONFLICT_LEDGER.csv","PROVENANCE.jsonl","METHODS.md","LIMITATIONS.md","PLOT_SPECS.json","WEB_TO_LOCAL_REQUEST.json","LOCAL_ABSORPTION_PROMPT.md","WINDOW_STATUS.json","MATRIX_CATE.csv","GRADE_TRANSFER_MATRIX.csv","BASELINE_MODERATION.csv","MATRIX_OVERLAP.csv","MANIFEST.json","CHECKSUMS.sha256"]
        self.assertEqual([x for x in req if not (ROOT/x).exists()],[])
    def test_effect_provenance(self):
        rows=list(csv.DictReader((ROOT/"EFFECT_ESTIMATES.csv").open(encoding="utf-8-sig")))
        self.assertEqual(len(rows),28)
        for r in rows:
            for k in ["paper_uid","control_sample_uid","treatment_sample_uid","condition_uid","source_locator"]: self.assertTrue(r[k])
    def test_transfer_errors_blank(self):
        rows=list(csv.DictReader((ROOT/"GRADE_TRANSFER_MATRIX.csv").open(encoding="utf-8-sig")))
        for r in rows:
            if r["source_grade"]!=r["target_grade"]:
                self.assertEqual(r["transfer_error"],""); self.assertIn("OOD",r["support_status"])
    def test_claim_locks(self):
        s=json.loads((ROOT/"WINDOW_STATUS.json").read_text())
        self.assertLessEqual(s["claim_level_max"],2); self.assertEqual(s["production_model_registration"],"FORBIDDEN"); self.assertEqual(s["gold_promotion"],"FORBIDDEN")
    def test_figures(self):
        stems=["F1_matrix_specific_reinforcement_effect_caterpillar","F2_baseline_strength_gain_relation","F3_grade_transfer_error_matrix","F4_overlap_applicability_domain_map"]
        for stem in stems:
            for ext in ["svg","pdf","png"]: self.assertGreater((ROOT/"figures"/f"{stem}.{ext}").stat().st_size,0)
    def test_checksums(self):
        for line in (ROOT/"CHECKSUMS.sha256").read_text().splitlines():
            d,r=line.split("  ",1); self.assertEqual(hashlib.sha256((ROOT/r).read_bytes()).hexdigest(),d,r)
    def test_status_data_gap(self):
        s=json.loads((ROOT/"WINDOW_STATUS.json").read_text()); self.assertEqual(s["status"],"CONTINUE_DATA_GAP"); self.assertEqual(s["snapshot_id"],"MISSING_Q40_INPUT_SNAPSHOT")
if __name__=="__main__": unittest.main()
