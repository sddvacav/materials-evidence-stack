# LIMITATIONS
1. Authoritative Q40 snapshot and official V29 UIDs were absent; all UIDs are deterministic provisional web UIDs.
2. Matrix family, paper, process, property mode, reinforcement identity and dose basis are strongly confounded.
3. Ti65 Table S1/Fig. S1 is missing; only relative +17/+16% is retained.
4. Ti-6Al-4V values are figure-derived approximations, not Gold-grade numeric evidence.
5. Actual TiB vol.% is unavailable for TA6.5 0.2 wt.% B; actual TiB/TiC fractions are unavailable for Beta21S B4C additions.
6. Tensile and compression effects are not pooled; nanoindentation is not bulk strength.
7. Replicate-level data and paired covariance are mostly absent; prediction intervals cannot be estimated honestly.
8. The overlap score is an audit diagnostic, not a probabilistic AD model.
9. Nothing in this package is production-model evidence, Gold promotion or a validated recipe.
